import mongoose from 'mongoose';

export let isMongoConnected = false;
export let connectionDetails = {
  uri: process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/mech_on_wheels',
  status: 'connecting',
  error: null,
  databaseName: 'mech_on_wheels'
};

export const connectDB = async (customUri = null) => {
  const uri = customUri || process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/mech_on_wheels';
  connectionDetails.uri = uri;
  connectionDetails.status = 'connecting';

  try {
    // If currently connected to another instance, disconnect first
    if (mongoose.connection.readyState !== 0) {
      await mongoose.disconnect();
    }

    mongoose.set('strictQuery', false);
    const conn = await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 4000,
      connectTimeoutMS: 5000,
    });

    isMongoConnected = true;
    connectionDetails.status = 'connected';
    connectionDetails.error = null;
    connectionDetails.databaseName = conn.connection.name || 'mech_on_wheels';
    console.log(`\n=========================================`);
    console.log(`✅ MongoDB Connected Successfully!`);
    console.log(`Host: ${conn.connection.host}`);
    console.log(`Database: ${conn.connection.name}`);
    console.log(`=========================================\n`);
    return { success: true, host: conn.connection.host, db: conn.connection.name };
  } catch (error) {
    isMongoConnected = false;
    connectionDetails.status = 'disconnected';
    connectionDetails.error = error.message;
    console.warn(`\n⚠️  Notice: MongoDB connection to "${uri}" was not established.`);
    console.warn(`Reason: ${error.message}`);
    console.log(`💡 The server will run with built-in resilient database storage.`);
    console.log(`💡 You can plug in MongoDB Atlas or a local MongoDB server anytime via the UI or .env!\n`);
    return { success: false, error: error.message };
  }
};

mongoose.connection.on('disconnected', () => {
  isMongoConnected = false;
  connectionDetails.status = 'disconnected';
});

mongoose.connection.on('connected', () => {
  isMongoConnected = true;
  connectionDetails.status = 'connected';
});
