import mongoose from 'mongoose';

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    phone: { type: String, required: true },
    role: {
      type: String,
      enum: ['customer', 'mechanic', 'admin'],
      default: 'customer'
    },
    avatar: { type: String, default: '' },
    provider: {
      type: String,
      enum: ['google', 'apple', 'microsoft', 'phone', 'email'],
      default: 'google'
    },
    providerId: { type: String, default: '' },
    // Mechanic-specific fields
    workshopName: { type: String, default: '' },
    specialties: [{ type: String }],
    experienceYears: { type: Number, default: 5 },
    rating: { type: Number, default: 4.8 },
    reviewCount: { type: Number, default: 24 },
    isVerified: { type: Boolean, default: true },
    isOnline: { type: Boolean, default: true },
    location: {
      address: { type: String, default: 'NH 44, Exit 123 Service Hub' },
      lat: { type: Number, default: 28.6139 },
      lng: { type: Number, default: 77.2090 }
    },
    vehicle: {
      type: { type: String, default: 'Service Van' },
      model: { type: String, default: 'Mech Mobile Repair Van' },
      plateNumber: { type: String, default: 'DL 01 MC 9988' }
    },
    earnings: {
      total: { type: Number, default: 18500 },
      completedJobs: { type: Number, default: 12 },
      commissionRate: { type: Number, default: 0.05 } // 5% minimal fee
    }
  },
  { timestamps: true }
);

export const User = mongoose.model('User', userSchema);
export default User;
