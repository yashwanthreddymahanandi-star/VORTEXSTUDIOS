import React from 'react';
import { useApp } from '../context/AppContext';
import { Wrench, ShieldCheck, Database, PhoneCall, HelpCircle, User, Car, Activity, Download, LogOut } from 'lucide-react';

export const Navbar = () => {
  const {
    user,
    logout,
    role,
    setRole,
    mongoStatus,
    setIsMongoModalOpen,
    setIsHowItWorksOpen
  } = useApp();

  return (
    <header className="sticky top-0 z-40 bg-[#070C18]/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & Tagline */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setRole('customer')}>
            <div className="relative flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-tr from-emerald-500/20 to-cyan-500/20 border border-emerald-500/40 shadow-lg shadow-emerald-500/10">
              <div className="absolute inset-0 rounded-xl bg-emerald-500/10 animate-pulse"></div>
              <Wrench className="w-6 h-6 text-emerald-400 rotate-45 transform" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xl md:text-2xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400">
                  MECH ON WHEELS
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  MERN STACK
                </span>
              </div>
              <p className="text-[11px] font-semibold tracking-wide text-slate-400 hidden sm:block">
                YOUR CAR BREAKS DOWN. <span className="text-emerald-400 font-bold">WE GET YOU BACK ON TRACK.</span>
              </p>
            </div>
          </div>

          {/* Navigation & Controls */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            
            {/* MongoDB Connection Status Pill */}
            <button
              onClick={() => setIsMongoModalOpen(true)}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg border text-xs font-medium transition-all ${
                mongoStatus.connected
                  ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-400 hover:bg-emerald-900/40 shadow-sm shadow-emerald-500/20'
                  : 'bg-amber-950/40 border-amber-500/40 text-amber-300 hover:bg-amber-900/40'
              }`}
              title="Click to view or update MongoDB connection"
            >
              <Database className="w-3.5 h-3.5" />
              <span className="flex h-2 w-2 relative">
                <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                  mongoStatus.connected ? 'bg-emerald-400' : 'bg-amber-400'
                }`}></span>
                <span className={`relative inline-flex rounded-full h-2 w-2 ${
                  mongoStatus.connected ? 'bg-emerald-500' : 'bg-amber-500'
                }`}></span>
              </span>
              <span className="hidden md:inline">
                {mongoStatus.connected ? 'MongoDB Connected' : 'MongoDB (Connect)'}
              </span>
            </button>

            {/* Download Project Source Code ZIP */}
            <a
              href="http://localhost:5000/api/download-zip"
              download="mech-on-wheels.zip"
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-xs font-semibold text-emerald-300 transition-colors shadow-sm"
              title="Download complete project source code ZIP"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">Download ZIP</span>
            </a>

            {/* How It Works Button */}
            <button
              onClick={() => setIsHowItWorksOpen(true)}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-xs font-semibold text-slate-300 transition-colors"
            >
              <HelpCircle className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden lg:inline">How It Works</span>
            </button>

            {/* Role Switcher Pill Container */}
            <div className="flex items-center bg-slate-900 p-1 rounded-xl border border-slate-800">
              <button
                onClick={() => setRole('customer')}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  role === 'customer'
                    ? 'bg-emerald-500 text-slate-950 shadow-md font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Car className="w-3.5 h-3.5" />
                <span>Vehicle Owner</span>
              </button>
              <button
                onClick={() => setRole('mechanic')}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  role === 'mechanic'
                    ? 'bg-cyan-500 text-slate-950 shadow-md font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Wrench className="w-3.5 h-3.5" />
                <span>Mechanic</span>
              </button>
              <button
                onClick={() => setRole('dispatch')}
                className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  role === 'dispatch'
                    ? 'bg-indigo-500 text-white shadow-md font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Activity className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Operations</span>
              </button>
            </div>

            {/* Emergency Hotline */}
            <a
              href="tel:1800-MECH-911"
              className="hidden xl:flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-400 text-xs font-bold"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>SOS: 1800-MECH-911</span>
            </a>

            {/* User Profile & Sign Out */}
            {user && (
              <div className="flex items-center space-x-2 pl-1 border-l border-slate-800">
                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <img
                      src={user.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=160&auto=format&fit=crop&q=80'}
                      alt={user.name}
                      className="w-8 h-8 rounded-full object-cover border border-slate-700"
                    />
                    <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full flex items-center justify-center text-[8px] bg-slate-900 border border-slate-700">
                      {user.provider === 'google' ? '🔴' : user.provider === 'apple' ? '🍏' : '🪟'}
                    </span>
                  </div>
                  <div className="hidden lg:block text-left">
                    <div className="text-xs font-bold text-white truncate max-w-[100px]">{user.name}</div>
                    <div className="text-[10px] text-slate-400 capitalize">{user.provider || 'Google'}</div>
                  </div>
                </div>

                <button
                  onClick={logout}
                  className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 border border-slate-700 transition-colors"
                  title="Sign Out"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

          </div>
        </div>
      </div>
    </header>
  );
};
