import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Wrench,
  ShieldCheck,
  Car,
  ChevronRight,
  Sparkles,
  ArrowRight,
  Lock,
  CheckCircle2,
  Phone
} from 'lucide-react';

export const LoginScreen = () => {
  const { loginWithSocial, role, setRole } = useApp();
  const [selectedRole, setSelectedRole] = useState(role || 'customer');
  const [customEmail, setCustomEmail] = useState('');
  const [customName, setCustomName] = useState('');
  const [showCustomModal, setShowCustomModal] = useState(false);
  const [activeProvider, setActiveProvider] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Handle Social Login Click
  const handleSocialClick = async (provider) => {
    setActiveProvider(provider);
    setIsLoading(true);
    setRole(selectedRole);

    // Simulate authentic OAuth handshake animation
    setTimeout(async () => {
      try {
        await loginWithSocial(provider, { role: selectedRole });
      } finally {
        setIsLoading(false);
        setActiveProvider(null);
      }
    }, 600);
  };

  const handleCustomSubmit = async (e) => {
    e.preventDefault();
    if (!customEmail) return;
    setIsLoading(true);
    try {
      const provider = customEmail.includes('gmail')
        ? 'google'
        : customEmail.includes('outlook') || customEmail.includes('hotmail')
        ? 'microsoft'
        : customEmail.includes('icloud') || customEmail.includes('apple')
        ? 'apple'
        : 'google';

      await loginWithSocial(provider, {
        email: customEmail,
        name: customName || customEmail.split('@')[0],
        role: selectedRole
      });
      setShowCustomModal(false);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#060B16] text-white flex flex-col justify-center items-center px-4 py-8 relative overflow-hidden">
      
      {/* Background glow effects */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[550px] bg-emerald-500/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-[400px] h-[400px] bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-md w-full relative z-10">
        
        {/* Brand Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500/20 via-teal-500/20 to-cyan-500/20 border border-emerald-500/40 shadow-2xl shadow-emerald-500/20 mb-4">
            <Wrench className="w-8 h-8 text-emerald-400 rotate-45 transform" />
          </div>

          <h1 className="text-3xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400">
            MECH ON WHEELS
          </h1>
          <p className="text-xs uppercase tracking-widest font-extrabold text-slate-400 mt-1">
            YOUR CAR BREAKS DOWN. <span className="text-emerald-400">WE GET YOU BACK ON TRACK.</span>
          </p>
        </div>

        {/* Main Auth Card */}
        <div className="bg-slate-900/90 backdrop-blur-xl border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
          
          <div className="text-center mb-6">
            <h2 className="text-xl font-extrabold text-white">Sign In to Continue</h2>
            <p className="text-xs text-slate-400 mt-1">
              Select your role and connect with Google, iOS/Apple, or Microsoft
            </p>
          </div>

          {/* Role Selector Tabs (Vehicle Owner vs Local Mechanic) */}
          <div className="mb-6">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
              Select Your Role:
            </div>
            <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1.5 rounded-2xl border border-slate-800">
              <button
                type="button"
                onClick={() => setSelectedRole('customer')}
                className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-1.5 ${
                  selectedRole === 'customer'
                    ? 'bg-emerald-500 text-slate-950 shadow-md font-black'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Car className="w-3.5 h-3.5" />
                <span>Vehicle Owner</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedRole('mechanic')}
                className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-1.5 ${
                  selectedRole === 'mechanic'
                    ? 'bg-cyan-500 text-slate-950 shadow-md font-black'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Wrench className="w-3.5 h-3.5" />
                <span>Local Mechanic</span>
              </button>
            </div>
          </div>

          {/* Social Sign-in Buttons */}
          <div className="space-y-3">
            
            {/* 1. GOOGLE SIGN IN (FIRST & MOST PROMINENT) */}
            <button
              onClick={() => handleSocialClick('google')}
              disabled={isLoading}
              className="w-full py-3.5 px-4 rounded-2xl bg-white hover:bg-slate-100 text-slate-900 font-extrabold text-sm shadow-xl shadow-white/5 transition-all flex items-center justify-between group active:scale-[0.98] border border-slate-200"
            >
              <div className="flex items-center space-x-3">
                {/* Official Google G SVG */}
                <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Continue with Google</span>
              </div>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                Primary
              </span>
            </button>

            {/* 2. APPLE / iOS SIGN IN */}
            <button
              onClick={() => handleSocialClick('apple')}
              disabled={isLoading}
              className="w-full py-3.5 px-4 rounded-2xl bg-black hover:bg-slate-950 text-white font-extrabold text-sm border border-slate-700 shadow-xl transition-all flex items-center justify-between active:scale-[0.98]"
            >
              <div className="flex items-center space-x-3">
                {/* Apple Logo SVG */}
                <svg className="w-5 h-5 shrink-0 fill-current" viewBox="0 0 170 170">
                  <path d="M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.19-2.12-9.97-3.17-14.34-3.17-4.58 0-9.49 1.05-14.75 3.17-5.26 2.13-9.5 3.24-12.74 3.35-4.35.13-9.16-1.9-14.42-6.08-3.69-3.04-7.69-7.85-12-14.43-6.3-9.67-11.45-20.2-15.45-31.6-4-11.4-6-22.3-6-32.7 0-14.37 3.58-26.68 10.74-36.93 7.16-10.25 16.32-15.48 27.48-15.7 4.58 0 9.8 1.25 15.66 3.75 5.86 2.5 9.77 3.75 11.73 3.75 1.52 0 5.66-1.33 12.43-4 6.77-2.67 12.42-3.83 16.94-3.5 12.63.66 22.84 5.37 30.63 14.13-11.09 6.74-16.53 16.09-16.31 28.05.22 9.57 3.86 17.61 10.92 24.13 7.07 6.52 15.43 10.22 25.11 11.1-2.18 6.52-4.89 13.04-8.15 19.57zM119.22 31.84c0-7.39 2.66-14.34 7.98-20.85 5.32-6.52 11.85-10.51 19.58-11.99.22 1.3.33 2.39.33 3.26 0 7.17-2.77 14.18-8.31 21.03-5.54 6.85-12.06 10.7-19.58 11.55v-3z"/>
                </svg>
                <span>Continue with Apple (iOS)</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500" />
            </button>

            {/* 3. MICROSOFT SIGN IN */}
            <button
              onClick={() => handleSocialClick('microsoft')}
              disabled={isLoading}
              className="w-full py-3.5 px-4 rounded-2xl bg-slate-950 hover:bg-slate-800 text-white font-extrabold text-sm border border-slate-700 shadow-xl transition-all flex items-center justify-between active:scale-[0.98]"
            >
              <div className="flex items-center space-x-3">
                {/* Microsoft 4-Color Grid */}
                <div className="w-5 h-5 grid grid-cols-2 gap-0.5 shrink-0">
                  <div className="bg-[#F25022]"></div>
                  <div className="bg-[#7FBA00]"></div>
                  <div className="bg-[#00A4EF]"></div>
                  <div className="bg-[#FFB900]"></div>
                </div>
                <span>Continue with Microsoft</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500" />
            </button>

          </div>

          {/* Divider */}
          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-800"></div>
            </div>
            <div className="relative flex justify-center text-[10px] uppercase font-bold tracking-widest text-slate-500">
              <span className="bg-slate-900 px-3">or enter your email</span>
            </div>
          </div>

          {/* Custom Email Form Button */}
          <button
            onClick={() => setShowCustomModal(true)}
            className="w-full py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all border border-slate-700 flex items-center justify-center space-x-2"
          >
            <span>Type Custom Email / Google Workspace</span>
          </button>

          {/* Instant One-Click Demo Mode Pills */}
          <div className="mt-6 pt-5 border-t border-slate-800/80">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 text-center mb-2.5">
              ⚡ Instant 1-Click Sandbox Logins:
            </div>
            <div className="flex flex-wrap gap-2 justify-center">
              <button
                onClick={() => {
                  setSelectedRole('customer');
                  handleSocialClick('google');
                }}
                className="px-3 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-semibold"
              >
                Driver: Rohit Verma
              </button>
              <button
                onClick={() => {
                  setSelectedRole('mechanic');
                  loginWithSocial('google', {
                    email: 'rajesh.mechpro@gmail.com',
                    name: 'Rajesh Kumar (Mech Pro)',
                    role: 'mechanic'
                  });
                }}
                className="px-3 py-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 text-xs font-semibold"
              >
                Mechanic: Mech Pro
              </button>
            </div>
          </div>

        </div>

        {/* Security & Warranty Footer */}
        <div className="text-center mt-6 text-xs text-slate-500 space-y-1">
          <div className="flex items-center justify-center space-x-1.5 text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>256-bit Encrypted SSL • Certified Roadside Mechanics</span>
          </div>
          <p>
            Emergency 24/7 Breakdown Hotline: <strong className="text-slate-300">1800-MECH-911</strong>
          </p>
        </div>

      </div>

      {/* Custom Email Modal */}
      {showCustomModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-6 shadow-2xl">
            <h3 className="text-base font-extrabold text-white mb-1">Enter Your Email</h3>
            <p className="text-xs text-slate-400 mb-4">
              We'll link your session automatically to your Google, Microsoft, or Apple account.
            </p>

            <form onSubmit={handleCustomSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Your Full Name</label>
                <input
                  type="text"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  placeholder="e.g. Aakash Sharma"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Email Address</label>
                <input
                  type="email"
                  value={customEmail}
                  onChange={(e) => setCustomEmail(e.target.value)}
                  placeholder="name@gmail.com"
                  required
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCustomModal(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold"
                >
                  Sign In
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
