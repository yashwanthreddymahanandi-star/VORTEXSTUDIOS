import { User } from '../models/User.js';
import { ServiceRequest } from '../models/ServiceRequest.js';
import { Quote } from '../models/Quote.js';
import { defaultMechanics, sampleRequests } from './seedData.js';
import { isMongoConnected } from '../config/db.js';

// In-memory memory-store for zero-latency lookups and seamless fallback
class MemoryStore {
  constructor() {
    this.mechanics = JSON.parse(JSON.stringify(defaultMechanics));
    this.requests = JSON.parse(JSON.stringify(sampleRequests));
    this.quotes = [
      {
        _id: 'quote_001',
        requestId: 'req_sample_101',
        mechanicId: 'mech_001',
        mechanicName: 'Mech Pro',
        shopName: 'Mech Pro Express',
        avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=160&auto=format&fit=crop&q=80',
        rating: 4.8,
        price: 1850,
        distanceKm: 2.4,
        etaMinutes: 8,
        breakdownNote: 'Full on-site diagnostic + electrical scan & repair',
        status: 'ACCEPTED'
      },
      {
        _id: 'quote_002',
        requestId: 'req_sample_101',
        mechanicId: 'mech_002',
        mechanicName: 'FixIt Auto',
        shopName: 'FixIt Auto Care',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&auto=format&fit=crop&q=80',
        rating: 4.6,
        price: 2150,
        distanceKm: 3.8,
        etaMinutes: 14,
        breakdownNote: 'Standard diagnostic & parts replacement',
        status: 'REJECTED'
      },
      {
        _id: 'quote_003',
        requestId: 'req_sample_101',
        mechanicId: 'mech_003',
        mechanicName: 'Speedy Service',
        shopName: 'Speedy Service 24/7',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=160&auto=format&fit=crop&q=80',
        rating: 4.7,
        price: 2400,
        distanceKm: 4.5,
        etaMinutes: 18,
        breakdownNote: 'Express van assistance with towing safety buffer',
        status: 'REJECTED'
      }
    ];
  }

  // Sync to MongoDB if connected
  async seedMongoIfConnected() {
    if (!isMongoConnected) return;
    try {
      const userCount = await User.countDocuments();
      if (userCount === 0) {
        console.log('🌱 Seeding default mechanics into MongoDB...');
        for (const m of this.mechanics) {
          const { _id, ...rest } = m;
          await User.create({ ...rest });
        }
      }

      const reqCount = await ServiceRequest.countDocuments();
      if (reqCount === 0) {
        console.log('🌱 Seeding initial active request into MongoDB...');
        for (const r of this.requests) {
          const { _id, ...rest } = r;
          await ServiceRequest.create({ ...rest });
        }
      }
      console.log('✅ MongoDB database verified with seed records!');
    } catch (err) {
      console.error('Error seeding MongoDB:', err.message);
    }
  }

  // Authenticate / Find or create user via Social Login (Google, Apple, Microsoft)
  async findOrCreateUser({ provider, email, name, avatar, role = 'customer', phone = '+91 98000 00000' }) {
    const cleanEmail = email.toLowerCase().trim();
    
    if (isMongoConnected) {
      try {
        let userDoc = await User.findOne({ email: cleanEmail });
        if (!userDoc) {
          userDoc = await User.create({
            name: name || cleanEmail.split('@')[0],
            email: cleanEmail,
            phone,
            role,
            avatar: avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanEmail}`,
            provider: provider || 'google',
            providerId: 'sso_' + Date.now()
          });
        }
        return userDoc;
      } catch (e) {
        console.error('Mongo user findOrCreate error:', e.message);
      }
    }

    // In-memory fallback
    if (!this.users) this.users = [];
    let user = this.users.find(u => u.email === cleanEmail);
    if (!user) {
      user = {
        _id: 'usr_' + Date.now(),
        name: name || cleanEmail.split('@')[0],
        email: cleanEmail,
        phone,
        role,
        avatar: avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanEmail}`,
        provider: provider || 'google',
        createdAt: new Date()
      };
      this.users.push(user);
    }
    return user;
  }

  // Get all mechanics
  async getMechanics() {
    if (isMongoConnected) {
      try {
        const docs = await User.find({ role: 'mechanic' });
        if (docs && docs.length > 0) return docs;
      } catch (e) {
        console.error('Mongo read error, falling back to memory:', e.message);
      }
    }
    return this.mechanics;
  }

  // Get mechanic by ID
  async getMechanicById(id) {
    if (isMongoConnected) {
      try {
        const doc = await User.findById(id);
        if (doc) return doc;
      } catch (e) {}
    }
    return this.mechanics.find(m => m._id === id || m.name.toLowerCase().includes(id.toLowerCase()));
  }

  // Get all requests
  async getRequests() {
    if (isMongoConnected) {
      try {
        const docs = await ServiceRequest.find().sort({ createdAt: -1 });
        if (docs && docs.length > 0) return docs;
      } catch (e) {
        console.error('Mongo read error, falling back to memory:', e.message);
      }
    }
    return this.requests;
  }

  // Get request by ID
  async getRequestById(id) {
    if (isMongoConnected) {
      try {
        const doc = await ServiceRequest.findById(id);
        if (doc) return doc;
      } catch (e) {}
    }
    return this.requests.find(r => r._id === id);
  }

  // Create new service request
  async createRequest(data) {
    const id = 'req_' + Date.now();
    const newReq = {
      _id: id,
      customerName: data.customerName || 'Driver',
      customerPhone: data.customerPhone || '+91 98000 00000',
      vehicle: {
        make: data.vehicle?.make || 'Toyota',
        model: data.vehicle?.model || 'Corolla',
        year: data.vehicle?.year || '2022',
        regNumber: data.vehicle?.regNumber || 'DL 01 AB 9999',
        type: data.vehicle?.type || 'Car'
      },
      location: {
        address: data.location?.address || 'NH 44, Near Exit 123',
        landmark: data.location?.landmark || 'Highway Stop',
        lat: data.location?.lat || 28.6139,
        lng: data.location?.lng || 77.2090
      },
      issue: {
        category: data.issue?.category || 'Engine Breakdown',
        description: data.issue?.description || 'Vehicle stalled on road',
        severity: data.issue?.severity || 'Urgent (High)',
        symptoms: data.issue?.symptoms || ['Warning Lights']
      },
      status: 'QUOTES_RECEIVED',
      currentStep: 3,
      selectedMechanic: null,
      tracking: {
        mechanicLat: 28.6250,
        mechanicLng: 77.2180,
        driverLat: data.location?.lat || 28.6139,
        driverLng: data.location?.lng || 77.2090,
        distanceKm: 2.4,
        etaMinutes: 8,
        routeProgress: 0,
        speedKmh: 45
      },
      estimate: {
        serviceCharge: 1100,
        parts: 500,
        taxes: 250,
        totalAmount: 1850,
        notes: 'Initial roadside diagnostic & repair estimate',
        approvedByCustomer: false,
        approvedAt: null
      },
      payment: {
        amount: 1850,
        status: 'Pending',
        method: 'UPI',
        invoiceNumber: 'INV-MOW-' + Math.floor(100000 + Math.random() * 900000),
        transactionId: '',
        paidAt: null
      },
      review: {
        rating: 0,
        feedback: '',
        tags: [],
        createdAt: null
      },
      createdAt: new Date(),
      updatedAt: new Date()
    };

    this.requests.unshift(newReq);

    // Automatically generate quotes from nearby mechanics matching Image 2!
    const autoQuotes = [
      {
        _id: 'quote_' + Date.now() + '_1',
        requestId: id,
        mechanicId: 'mech_001',
        mechanicName: 'Mech Pro',
        shopName: 'Mech Pro Express',
        avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=160&auto=format&fit=crop&q=80',
        rating: 4.8,
        price: 1850,
        distanceKm: 2.4,
        etaMinutes: 8,
        breakdownNote: 'Immediate on-site mobile unit dispatch with diagnostic OBD-II scanner',
        status: 'PENDING'
      },
      {
        _id: 'quote_' + Date.now() + '_2',
        requestId: id,
        mechanicId: 'mech_002',
        mechanicName: 'FixIt Auto',
        shopName: 'FixIt Auto Care',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&auto=format&fit=crop&q=80',
        rating: 4.6,
        price: 2150,
        distanceKm: 3.8,
        etaMinutes: 14,
        breakdownNote: 'Certified mechanic van with complete toolset and spare fuses',
        status: 'PENDING'
      },
      {
        _id: 'quote_' + Date.now() + '_3',
        requestId: id,
        mechanicId: 'mech_003',
        mechanicName: 'Speedy Service',
        shopName: 'Speedy Service 24/7',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=160&auto=format&fit=crop&q=80',
        rating: 4.7,
        price: 2400,
        distanceKm: 4.5,
        etaMinutes: 18,
        breakdownNote: 'Heavy duty mobile breakdown recovery + 30 days warranty',
        status: 'PENDING'
      }
    ];

    this.quotes.push(...autoQuotes);

    // Save to Mongo if connected
    if (isMongoConnected) {
      try {
        const mongoReq = new ServiceRequest(newReq);
        await mongoReq.save();
        for (const q of autoQuotes) {
          const mongoQuote = new Quote(q);
          await mongoQuote.save();
        }
      } catch (err) {
        console.error('Mongo save error:', err.message);
      }
    }

    return { request: newReq, quotes: autoQuotes };
  }

  // Get quotes for request
  async getQuotesForRequest(requestId) {
    if (isMongoConnected) {
      try {
        const docs = await Quote.find({ requestId });
        if (docs && docs.length > 0) return docs;
      } catch (e) {}
    }
    return this.quotes.filter(q => q.requestId === requestId);
  }

  // Accept a quote
  async acceptQuote(requestId, quoteId) {
    const req = this.requests.find(r => r._id === requestId);
    const quote = this.quotes.find(q => q._id === quoteId);

    if (!req || !quote) throw new Error('Request or Quote not found');

    // Update quote statuses
    this.quotes.forEach(q => {
      if (q.requestId === requestId) {
        q.status = q._id === quoteId ? 'ACCEPTED' : 'REJECTED';
      }
    });

    // Update request
    req.status = 'EN_ROUTE';
    req.currentStep = 6;
    req.selectedMechanic = {
      mechanicId: quote.mechanicId,
      name: quote.mechanicName,
      shopName: quote.shopName,
      avatar: quote.avatar,
      rating: quote.rating,
      phone: '+91 98765 43210',
      vanModel: 'Mech On Wheels Rapid Response Van'
    };
    req.tracking = {
      ...req.tracking,
      distanceKm: quote.distanceKm || 2.4,
      etaMinutes: quote.etaMinutes || 8,
      routeProgress: 15
    };
    req.estimate.totalAmount = quote.price;
    req.estimate.serviceCharge = Math.round(quote.price * 0.6);
    req.estimate.parts = Math.round(quote.price * 0.27);
    req.estimate.taxes = quote.price - req.estimate.serviceCharge - req.estimate.parts;
    req.payment.amount = quote.price;

    if (isMongoConnected) {
      try {
        await ServiceRequest.findOneAndUpdate({ _id: requestId }, req);
        await Quote.updateMany({ requestId }, { status: 'REJECTED' });
        await Quote.findOneAndUpdate({ _id: quoteId }, { status: 'ACCEPTED' });
      } catch (e) {
        console.error('Mongo update error:', e.message);
      }
    }

    return { request: req, acceptedQuote: quote };
  }

  // Update request status / step
  async updateRequestStep(requestId, nextStep, statusName, additionalData = {}) {
    const req = this.requests.find(r => r._id === requestId);
    if (!req) throw new Error('Request not found');

    req.currentStep = nextStep;
    if (statusName) req.status = statusName;

    if (additionalData.tracking) {
      req.tracking = { ...req.tracking, ...additionalData.tracking };
    }
    if (additionalData.estimate) {
      req.estimate = { ...req.estimate, ...additionalData.estimate };
    }
    if (additionalData.payment) {
      req.payment = { ...req.payment, ...additionalData.payment };
    }
    if (additionalData.review) {
      req.review = { ...req.review, ...additionalData.review };
    }

    req.updatedAt = new Date();

    if (isMongoConnected) {
      try {
        await ServiceRequest.findOneAndUpdate({ _id: requestId }, req);
      } catch (e) {
        console.error('Mongo update error:', e.message);
      }
    }

    return req;
  }

  // Add custom mechanic quote
  async addQuote(data) {
    const newQuote = {
      _id: 'quote_' + Date.now(),
      requestId: data.requestId,
      mechanicId: data.mechanicId || 'mech_001',
      mechanicName: data.mechanicName || 'Verified Mechanic',
      shopName: data.shopName || 'Mobile Auto Tech',
      avatar: data.avatar || 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=160&auto=format&fit=crop&q=80',
      rating: data.rating || 4.8,
      price: Number(data.price) || 1850,
      distanceKm: Number(data.distanceKm) || 2.5,
      etaMinutes: Number(data.etaMinutes) || 10,
      breakdownNote: data.breakdownNote || 'Fair price estimate & guaranteed roadside repair',
      status: 'PENDING'
    };

    this.quotes.push(newQuote);

    if (isMongoConnected) {
      try {
        const qDoc = new Quote(newQuote);
        await qDoc.save();
      } catch (e) {}
    }

    return newQuote;
  }
}

export const store = new MemoryStore();
