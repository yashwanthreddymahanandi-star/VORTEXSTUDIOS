import mongoose from 'mongoose';

const quoteSchema = new mongoose.Schema(
  {
    requestId: { type: String, required: true },
    mechanicId: { type: String, required: true },
    mechanicName: { type: String, required: true },
    shopName: { type: String, required: true },
    avatar: { type: String, default: '' },
    rating: { type: Number, default: 4.8 },
    reviewCount: { type: Number, default: 45 },
    distanceKm: { type: Number, default: 2.4 },
    etaMinutes: { type: Number, default: 12 },
    price: { type: Number, required: true }, // e.g. 1850, 2150, 2400
    breakdownNote: { type: String, default: 'Includes mobile diagnostic, roadside assistance & labour' },
    status: {
      type: String,
      enum: ['PENDING', 'ACCEPTED', 'REJECTED'],
      default: 'PENDING'
    }
  },
  { timestamps: true }
);

export const Quote = mongoose.model('Quote', quoteSchema);
export default Quote;
