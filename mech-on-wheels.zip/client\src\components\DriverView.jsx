import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { InteractiveMap } from './InteractiveMap';
import confetti from 'canvas-confetti';
import {
  AlertTriangle,
  MapPin,
  Car,
  Wrench,
  CheckCircle,
  Star,
  Clock,
  ShieldCheck,
  CreditCard,
  Download,
  Phone,
  MessageSquare,
  Sparkles,
  ChevronRight,
  ArrowRight,
  DollarSign
} from 'lucide-react';

export const DriverView = () => {
  const {
    currentRequest,
    quotesList,
    createServiceRequest,
    acceptQuote,
    updateStep,
    approveEstimate,
    processPayment,
    submitReview,
    setIsInvoiceOpen
  } = useApp();

  const currentStep = currentRequest?.currentStep || 2;

  // New Request Form State
  const [formData, setFormData] = useState({
    customerName: 'Rohit Verma',
    customerPhone: '+91 98700 12345',
    vehicleMake: 'Hyundai',
    vehicleModel: 'Verna 1.6 SX',
    vehicleYear: '2023',
    vehicleReg: 'DL 08 CD 4455',
    vehicleType: 'Car',
    address: 'NH 44, Near Exit 123',
    landmark: 'Near Milestone 123 & Petrol Pump',
    category: 'Engine Breakdown',
    severity: 'Urgent (High)',
    description: 'Vehicle stalled abruptly with battery & check engine warning flashing.'
  });

  // Payment Form State
  const [paymentMethod, setPaymentMethod] = useState('UPI');
  const [isProcessingPay, setIsProcessingPay] = useState(false);

  // Review Form State
  const [userRating, setUserRating] = useState(5);
  const [reviewText, setReviewText] = useState('Excellent mechanic! Reached within 10 minutes and resolved the engine wiring issue on the spot.');
  const [selectedTags, setSelectedTags] = useState(['Fast Response', 'Transparent Pricing', 'Skilled Mechanic']);

  // Handle Create Request Submit
  const handleRequestSubmit = async (e) => {
    e.preventDefault();
    await createServiceRequest({
      customerName: formData.customerName,
      customerPhone: formData.customerPhone,
      vehicle: {
        make: formData.vehicleMake,
        model: formData.vehicleModel,
        year: formData.vehicleYear,
        regNumber: formData.vehicleReg,
        type: formData.vehicleType
      },
      location: {
        address: formData.address,
        landmark: formData.landmark,
        lat: 28.6139,
        lng: 77.2090
      },
      issue: {
        category: formData.category,
        description: formData.description,
        severity: formData.severity,
        symptoms: ['Engine Stall', 'Battery Warning', 'Power Loss']
      }
    });
  };

  // Trigger Confetti Celebration
  const triggerCelebration = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 }
    });
  };

  return (
    <div className="space-y-6">
      
      {/* ================= STEP 1: BREAKDOWN SAFETY ALERT ================= */}
      <div className="bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-slate-900 border border-amber-500/30 rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center shrink-0">
            <AlertTriangle className="w-6 h-6 text-amber-400 animate-bounce" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs uppercase font-extrabold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                Step 1: Vehicle Breakdown
              </span>
              <span className="text-xs text-slate-400 font-medium">Roadside Safety Tips</span>
            </div>
            <h2 className="text-lg font-bold text-white mt-1">
              Your car breaks down on the road. Stay safe & request instant help!
            </h2>
            <p className="text-xs text-slate-300 mt-0.5">
              Turn on your hazard lights, stay behind the highway barrier, and open the app to notify certified mobile mechanics.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          <button
            onClick={() => updateStep(2, 'REQUEST_SUBMITTED')}
            className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold shadow-lg shadow-emerald-500/20 transition-all flex items-center space-x-1.5"
          >
            <span>Raise New Request</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* ================= STEP 2: OPEN APP & REQUEST SERVICE ================= */}
      {currentStep <= 2 && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <div className="border-b border-slate-800 pb-4 mb-6 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black">
                2
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Open App & Request Service</h3>
                <p className="text-xs text-slate-400">Share your breakdown location and define vehicle issues</p>
              </div>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              Instant Dispatch
            </span>
          </div>

          <form onSubmit={handleRequestSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Location Section */}
              <div className="space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
                  <MapPin className="w-4 h-4 text-emerald-400" />
                  <span>Breakdown Location</span>
                </h4>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Exact Location / Highway Marker
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      required
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 pl-10"
                      placeholder="e.g. NH 44, Near Exit 123"
                    />
                    <MapPin className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Nearby Landmark / Reference
                  </label>
                  <input
                    type="text"
                    value={formData.landmark}
                    onChange={(e) => setFormData({ ...formData, landmark: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500"
                    placeholder="e.g. Near HP Petrol Pump, Milestone 123"
                  />
                </div>

                <div className="flex items-center space-x-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setFormData({
                        ...formData,
                        address: 'NH 44, Near Exit 123 (GPS Detected)',
                        landmark: 'Flyover Northbound Pillar 42'
                      });
                    }}
                    className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-emerald-400 font-semibold border border-slate-700"
                  >
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                    <span>Auto-Detect Current GPS Coordinates</span>
                  </button>
                </div>
              </div>

              {/* Vehicle & Issue Details */}
              <div className="space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
                  <Car className="w-4 h-4 text-cyan-400" />
                  <span>Vehicle & Breakdown Details</span>
                </h4>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Make & Model</label>
                    <input
                      type="text"
                      value={formData.vehicleMake + ' ' + formData.vehicleModel}
                      onChange={(e) => setFormData({ ...formData, vehicleMake: e.target.value })}
                      required
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Plate / Reg Number</label>
                    <input
                      type="text"
                      value={formData.vehicleReg}
                      onChange={(e) => setFormData({ ...formData, vehicleReg: e.target.value })}
                      required
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500 uppercase"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Issue Category</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Engine Breakdown">Engine Breakdown / Power Loss</option>
                    <option value="Flat Tyre">Flat Tyre / Puncture</option>
                    <option value="Battery Jumpstart">Dead Battery / Jumpstart Required</option>
                    <option value="Overheating">Coolant Leak / Radiator Overheating</option>
                    <option value="Brake Failure">Brake Failure / Fluid Leak</option>
                    <option value="Fuel Delivery">Out of Fuel / Wrong Fuel</option>
                    <option value="Locked Out">Locked Out / Key Stuck</option>
                    <option value="Towing">Flatbed Towing Needed</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Issue Description</label>
                  <textarea
                    rows={2}
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end">
              <button
                type="submit"
                className="w-full sm:w-auto px-8 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-sm shadow-xl shadow-emerald-500/20 transition-all flex items-center justify-center space-x-2"
              >
                <Wrench className="w-4 h-4" />
                <span>REQUEST SERVICE (BROADCAST TO MECHANICS)</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ================= STEPS 3 & 4: COMPARE COMPETITIVE QUOTES ================= */}
      {currentStep >= 3 && currentStep <= 4 && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-2 mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-black">
                3
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Compare Competitive Quotes</h3>
                <p className="text-xs text-slate-400">
                  Nearby verified mechanics review your callout and send transparent price quotes
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2 text-xs text-emerald-400 font-semibold bg-emerald-500/10 px-3 py-1.5 rounded-lg border border-emerald-500/20">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span>{quotesList.length} Mechanics Responded</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {quotesList.map((q, idx) => {
              const isBest = idx === 0; // Mech Pro is lowest & highest rating
              return (
                <div
                  key={q._id}
                  className={`relative rounded-2xl p-5 border transition-all duration-300 flex flex-col justify-between ${
                    isBest
                      ? 'bg-gradient-to-b from-slate-900 to-emerald-950/30 border-emerald-500/60 shadow-xl shadow-emerald-500/10 ring-1 ring-emerald-500/40'
                      : 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {isBest && (
                    <div className="absolute -top-3 left-4 bg-emerald-500 text-slate-950 text-[10px] font-black uppercase px-3 py-0.5 rounded-full shadow-md">
                      ★ Best Option
                    </div>
                  )}

                  <div>
                    {/* Mechanic Avatar & Name */}
                    <div className="flex items-center space-x-3 mb-4">
                      <img
                        src={q.avatar}
                        alt={q.mechanicName}
                        className="w-12 h-12 rounded-xl object-cover border border-slate-700 shadow-md"
                      />
                      <div>
                        <h4 className="font-extrabold text-white text-base flex items-center space-x-1.5">
                          <span>{q.mechanicName}</span>
                          <ShieldCheck className="w-4 h-4 text-emerald-400" />
                        </h4>
                        <div className="flex items-center space-x-2 text-xs mt-0.5">
                          <span className="flex items-center space-x-1 text-amber-400 font-bold">
                            <Star className="w-3.5 h-3.5 fill-current" />
                            <span>{q.rating}</span>
                          </span>
                          <span className="text-slate-500">•</span>
                          <span className="text-slate-400">{q.shopName}</span>
                        </div>
                      </div>
                    </div>

                    {/* Breakdown Details */}
                    <div className="bg-slate-900/80 rounded-xl p-3 border border-slate-800 space-y-2 mb-4 text-xs">
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400 flex items-center space-x-1">
                          <Clock className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Estimated Arrival:</span>
                        </span>
                        <span className="font-bold text-white">{q.etaMinutes || 10} mins</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400 flex items-center space-x-1">
                          <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Distance:</span>
                        </span>
                        <span className="font-bold text-white">{q.distanceKm || 2.4} km away</span>
                      </div>
                      <div className="pt-1 text-[11px] text-slate-300 border-t border-slate-800">
                        {q.breakdownNote}
                      </div>
                    </div>
                  </div>

                  {/* Price & Action */}
                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                    <div>
                      <div className="text-[10px] uppercase font-bold text-slate-400">Total Price Quote</div>
                      <div className="text-2xl font-black text-emerald-400">
                        ₹{q.price?.toLocaleString()}
                      </div>
                    </div>

                    <button
                      onClick={() => acceptQuote(q._id)}
                      className={`px-4 py-2.5 rounded-xl font-bold text-xs shadow-md transition-all flex items-center space-x-1 ${
                        isBest
                          ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black'
                          : 'bg-slate-800 hover:bg-slate-700 text-white'
                      }`}
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>Choose Option</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ================= STEP 5 & 6: REAL-TIME TRACKING ================= */}
      {currentStep >= 5 && currentStep <= 6 && (
        <div className="space-y-4">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-black">
                  6
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                    <span>Track Mechanic in Real-Time</span>
                    <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-semibold border border-emerald-500/30">
                      En Route
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Live GPS navigation showing mechanic heading towards your breakdown point
                  </p>
                </div>
              </div>

              {/* Mechanic Quick Call */}
              <div className="flex items-center space-x-2">
                <a
                  href={`tel:${currentRequest?.selectedMechanic?.phone || '+919876543210'}`}
                  className="px-3.5 py-2 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold flex items-center space-x-1.5"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Call Mechanic</span>
                </a>
                <button
                  onClick={() => updateStep(7, 'ARRIVED')}
                  className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-extrabold shadow-md"
                >
                  Mechanic Reached (Step 7)
                </button>
              </div>
            </div>

            {/* Live Interactive Vector Road Map */}
            <div className="mt-4">
              <InteractiveMap />
            </div>
          </div>
        </div>
      )}

      {/* ================= STEP 7 & 8: ON-SITE DIAGNOSIS & TRANSPARENT PRICING ================= */}
      {currentStep >= 7 && currentStep <= 8 && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-2 mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-black">
                8
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Transparent Pricing & Estimate Approval</h3>
                <p className="text-xs text-slate-400">
                  Mechanic inspected the issue on-site. Review the clear itemized estimate before repair begins.
                </p>
              </div>
            </div>
            <div className="text-xs font-bold text-amber-300 bg-amber-500/10 border border-amber-500/30 px-3 py-1.5 rounded-lg flex items-center space-x-1.5">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span>No Hidden Charges Guarantee</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Mechanic Inspection Summary */}
            <div className="bg-slate-950/80 rounded-2xl p-5 border border-slate-800 space-y-4">
              <div className="flex items-center space-x-3">
                <img
                  src={currentRequest?.selectedMechanic?.avatar || 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=160&auto=format&fit=crop&q=80'}
                  alt="Mechanic"
                  className="w-12 h-12 rounded-xl object-cover border border-slate-700"
                />
                <div>
                  <h4 className="text-white font-bold text-sm">
                    {currentRequest?.selectedMechanic?.name || 'Rajesh Kumar (Mech Pro)'}
                  </h4>
                  <p className="text-xs text-slate-400">On-Site Diagnosis Report</p>
                </div>
              </div>

              <div className="p-3 bg-slate-900 rounded-xl text-xs text-slate-300 border border-slate-800 space-y-2">
                <div className="font-bold text-emerald-400">Diagnosis Findings:</div>
                <p>
                  Scanned with OBD-II mobile scanner. Alternator connector loose with primary 60A fuse blown due to voltage spike. Engine sensors intact.
                </p>
                <div className="font-bold text-slate-200 pt-1">Proposed Fix:</div>
                <p>
                  Replace OEM harness fuse, clean terminals, test battery alternator load voltage, verify idle stabilization.
                </p>
              </div>
            </div>

            {/* Itemized Transparent Pricing Table (Matching Screenshot Step 8) */}
            <div className="bg-slate-950/80 rounded-2xl p-5 border border-slate-800 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Itemized Billing
                  </span>
                  <span className="text-xs font-bold text-emerald-400">Fixed Transparent Rate</span>
                </div>

                <div className="py-3 space-y-2.5 text-sm">
                  <div className="flex justify-between items-center text-slate-300">
                    <span>Roadside Diagnostic & Service Charge</span>
                    <span className="font-bold text-white">₹1,100</span>
                  </div>
                  <div className="flex justify-between items-center text-slate-300">
                    <span>Quality Replacement Parts (60A OEM Fuse & Clamp)</span>
                    <span className="font-bold text-white">₹500</span>
                  </div>
                  <div className="flex justify-between items-center text-slate-300">
                    <span>Applicable GST / Taxes</span>
                    <span className="font-bold text-white">₹250</span>
                  </div>
                  <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-base font-extrabold text-white">
                    <span>Total Estimated Cost</span>
                    <span className="text-xl text-emerald-400 font-black">₹1,850</span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800/80">
                <button
                  onClick={() => approveEstimate({ serviceCharge: 1100, parts: 500, taxes: 250 })}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-sm shadow-xl shadow-emerald-500/20 flex items-center justify-center space-x-2"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>CONFIRM & PROCEED (APPROVE REPAIR)</span>
                </button>
                <p className="text-[11px] text-center text-slate-400 mt-2">
                  No payment required right now. You pay securely after the repair is completed.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= STEP 9: REPAIR IN PROGRESS ================= */}
      {currentStep === 9 && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl text-center">
          <div className="w-16 h-16 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-400 flex items-center justify-center mx-auto mb-4">
            <Wrench className="w-8 h-8 animate-spin" style={{ animationDuration: '4s' }} />
          </div>
          <span className="text-xs uppercase font-extrabold px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
            Step 9: Repair in Progress
          </span>
          <h3 className="text-xl font-black text-white mt-3">
            Your vehicle is being repaired on-site
          </h3>
          <p className="text-sm text-slate-300 max-w-md mx-auto mt-1">
            The certified mechanic is using genuine quality parts and specialized diagnostic tools. Sit back safely!
          </p>

          <div className="max-w-md mx-auto mt-6">
            <div className="w-full bg-slate-800 rounded-full h-3 overflow-hidden">
              <div className="bg-gradient-to-r from-cyan-400 to-emerald-400 h-full rounded-full w-3/4 animate-pulse"></div>
            </div>
            <div className="flex justify-between text-xs text-slate-400 mt-2">
              <span>Replacing OEM fuse & wiring check</span>
              <span className="font-bold text-emerald-400">75% Complete</span>
            </div>
          </div>

          <div className="mt-8 flex justify-center space-x-3">
            <button
              onClick={() => updateStep(10, 'PAYMENT_PENDING')}
              className="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20"
            >
              Mechanic Finished Repair (Proceed to Payment)
            </button>
          </div>
        </div>
      )}

      {/* ================= STEP 10: PAY SECURELY IN-APP ================= */}
      {currentStep === 10 && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-2 mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black">
                10
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Pay Securely In-App</h3>
                <p className="text-xs text-slate-400">
                  Make a seamless payment through UPI, Card, or Cash. Download instant tax invoice.
                </p>
              </div>
            </div>
            <div className="text-xl font-black text-emerald-400">
              Total Amount: ₹1,850
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Payment Method Selector */}
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Choose Payment Method
              </h4>

              <div className="space-y-2.5">
                {[
                  { id: 'UPI', label: 'UPI / QR Code (Google Pay, PhonePe, Paytm)', desc: 'Instant 0% surcharge' },
                  { id: 'Card', label: 'Credit or Debit Card', desc: 'Visa, Mastercard, RuPay' },
                  { id: 'Netbanking', label: 'Net Banking', desc: 'All Indian banks supported' },
                  { id: 'Cash', label: 'Cash to Mechanic On-Site', desc: 'Pay directly after verification' }
                ].map((m) => (
                  <label
                    key={m.id}
                    onClick={() => setPaymentMethod(m.id)}
                    className={`flex items-start justify-between p-3.5 rounded-xl border cursor-pointer transition-all ${
                      paymentMethod === m.id
                        ? 'bg-emerald-500/10 border-emerald-500 text-white shadow-md'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div>
                      <div className="text-sm font-bold text-white">{m.label}</div>
                      <div className="text-xs text-slate-400">{m.desc}</div>
                    </div>
                    <div className={`w-4 h-4 rounded-full border flex items-center justify-center mt-1 ${
                      paymentMethod === m.id ? 'border-emerald-500 bg-emerald-500' : 'border-slate-600'
                    }`}>
                      {paymentMethod === m.id && <div className="w-1.5 h-1.5 rounded-full bg-slate-950" />}
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Checkout Confirmation Card */}
            <div className="bg-slate-950/80 rounded-2xl p-5 border border-slate-800 flex flex-col justify-between">
              <div>
                <div className="text-xs uppercase font-bold text-slate-400 pb-2 border-b border-slate-800">
                  Order Summary
                </div>
                <div className="py-3 space-y-2 text-xs">
                  <div className="flex justify-between text-slate-300">
                    <span>Vehicle:</span>
                    <span className="font-bold text-white">{currentRequest?.vehicle?.make} {currentRequest?.vehicle?.model}</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Mechanic:</span>
                    <span className="font-bold text-white">{currentRequest?.selectedMechanic?.name || 'Mech Pro'}</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Service:</span>
                    <span className="font-bold text-white">Roadside Diagnostic & Alternator Repair</span>
                  </div>
                  <div className="pt-2 border-t border-slate-800 flex justify-between text-sm font-extrabold text-white">
                    <span>Total Due:</span>
                    <span className="text-emerald-400 font-black text-lg">₹1,850</span>
                  </div>
                </div>

                {paymentMethod === 'UPI' && (
                  <div className="bg-slate-900 rounded-xl p-3 border border-slate-800 text-center my-2">
                    <div className="text-[11px] font-bold text-slate-300 mb-1">Scan & Pay via any UPI App</div>
                    <div className="w-24 h-24 bg-white rounded-lg p-1.5 mx-auto flex items-center justify-center shadow">
                      {/* Stylized QR mockup */}
                      <div className="w-full h-full bg-slate-950 p-1 flex flex-wrap gap-1">
                        <div className="w-6 h-6 bg-white rounded-sm"></div>
                        <div className="w-4 h-6 bg-emerald-400 rounded-sm"></div>
                        <div className="w-6 h-4 bg-cyan-400 rounded-sm"></div>
                        <div className="w-6 h-6 bg-white rounded-sm"></div>
                      </div>
                    </div>
                    <span className="text-[10px] text-slate-400 block mt-1 font-mono">
                      UPI ID: mechwheels@okaxis
                    </span>
                  </div>
                )}
              </div>

              <div className="pt-4">
                <button
                  onClick={async () => {
                    setIsProcessingPay(true);
                    setTimeout(async () => {
                      await processPayment({ method: paymentMethod, amount: 1850 });
                      setIsProcessingPay(false);
                      triggerCelebration();
                    }, 800);
                  }}
                  disabled={isProcessingPay}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-sm shadow-xl shadow-emerald-500/20 flex items-center justify-center space-x-2 transition-all"
                >
                  <CreditCard className="w-4 h-4" />
                  <span>{isProcessingPay ? 'Processing Secure Payment...' : 'PAY ₹1,850 NOW'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= STEP 11 & 12: GET BACK ON THE ROAD & RATE/REVIEW ================= */}
      {currentStep >= 11 && (
        <div className="space-y-6">
          
          {/* Step 11: Get Back on the Road Card */}
          <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900 to-cyan-950/40 border border-emerald-500/40 rounded-2xl p-6 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="flex items-center space-x-4">
              <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 text-2xl font-black shrink-0">
                🚗💨
              </div>
              <div>
                <span className="text-xs uppercase font-extrabold px-3 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Step 11: Get Back on the Road
                </span>
                <h3 className="text-2xl font-black text-white mt-1">
                  You're all set! Hit the road with peace of mind.
                </h3>
                <p className="text-xs text-slate-300 mt-1">
                  Your vehicle has been repaired on-site, test-run verified, and digital payment confirmed.
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-3 shrink-0">
              <button
                onClick={() => setIsInvoiceOpen(true)}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold border border-slate-700 flex items-center space-x-1.5 shadow-md"
              >
                <Download className="w-3.5 h-3.5 text-emerald-400" />
                <span>Download Invoice</span>
              </button>
            </div>
          </div>

          {/* Step 12: Rate & Review Experience */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <div className="border-b border-slate-800 pb-4 mb-6 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-black">
                  12
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Rate & Review Your Experience</h3>
                  <p className="text-xs text-slate-400">Help us maintain top quality roadside support</p>
                </div>
              </div>
              <span className="text-xs font-bold text-amber-400 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">
                Verified Customer Feedback
              </span>
            </div>

            <div className="max-w-xl mx-auto space-y-5">
              {/* Star Rating */}
              <div className="text-center">
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  How was your experience with {currentRequest?.selectedMechanic?.name || 'Mech Pro'}?
                </div>
                <div className="flex justify-center space-x-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setUserRating(star)}
                      className="p-1 focus:outline-none transition-transform hover:scale-125"
                    >
                      <Star
                        className={`w-8 h-8 ${
                          star <= userRating
                            ? 'text-amber-400 fill-amber-400 drop-shadow'
                            : 'text-slate-700'
                        }`}
                      />
                    </button>
                  ))}
                </div>
                <div className="text-xs font-bold text-amber-400 mt-1">
                  {userRating === 5 ? 'Exceptional Service ★★★★★' : `${userRating} Stars`}
                </div>
              </div>

              {/* Compliments Badges */}
              <div>
                <div className="text-xs font-semibold text-slate-300 mb-2">Select Compliments:</div>
                <div className="flex flex-wrap gap-2">
                  {['Fast Response', 'Transparent Pricing', 'Skilled Mechanic', 'Quality Parts', 'Courteous Behavior'].map((tag) => {
                    const isSelected = selectedTags.includes(tag);
                    return (
                      <button
                        key={tag}
                        type="button"
                        onClick={() => {
                          if (isSelected) {
                            setSelectedTags(selectedTags.filter(t => t !== tag));
                          } else {
                            setSelectedTags([...selectedTags, tag]);
                          }
                        }}
                        className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                          isSelected
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : 'bg-slate-800 text-slate-400 border border-slate-700 hover:text-slate-200'
                        }`}
                      >
                        {isSelected ? '✓ ' : '+ '} {tag}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Written Review */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Detailed Feedback (Saved to MongoDB)
                </label>
                <textarea
                  rows={3}
                  value={reviewText}
                  onChange={(e) => setReviewText(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500"
                  placeholder="Share details about the repair and arrival time..."
                />
              </div>

              <div className="flex justify-end space-x-3 pt-2">
                <button
                  onClick={() => setIsInvoiceOpen(true)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs"
                >
                  View Tax Invoice
                </button>
                <button
                  onClick={async () => {
                    await submitReview({ rating: userRating, feedback: reviewText, tags: selectedTags });
                    triggerCelebration();
                  }}
                  className="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs shadow-lg shadow-emerald-500/20 flex items-center space-x-1.5"
                >
                  <Star className="w-3.5 h-3.5 fill-current" />
                  <span>SUBMIT REVIEW TO MONGODB</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= BOTTOM VALUE PROPOSITIONS (Matching Screenshot Footer) ================= */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 pt-4 border-t border-slate-800/80">
        <div className="flex items-center space-x-3 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
            <Phone className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-extrabold text-white">24/7 SUPPORT</div>
            <div className="text-[10px] text-slate-400">Here anytime, anywhere.</div>
          </div>
        </div>

        <div className="flex items-center space-x-3 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-extrabold text-white">EXPERT MECHANICS</div>
            <div className="text-[10px] text-slate-400">Verified professionals.</div>
          </div>
        </div>

        <div className="flex items-center space-x-3 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
            <Clock className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-extrabold text-white">QUICK RESPONSE</div>
            <div className="text-[10px] text-slate-400">Nearest mobile units.</div>
          </div>
        </div>

        <div className="flex items-center space-x-3 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
            <DollarSign className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-extrabold text-white">TRANSPARENT PRICING</div>
            <div className="text-[10px] text-slate-400">No hidden charges.</div>
          </div>
        </div>

        <div className="col-span-2 md:col-span-1 flex items-center space-x-3 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
          <div className="w-8 h-8 rounded-lg bg-teal-500/10 text-teal-400 flex items-center justify-center shrink-0">
            <CheckCircle className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-extrabold text-white">QUALITY ASSURANCE</div>
            <div className="text-[10px] text-slate-400">Reliable repair guarantee.</div>
          </div>
        </div>
      </div>

    </div>
  );
};
