import React, { createContext, useContext, useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import axios from 'axios';

const AppContext = createContext();

export const AppProvider = ({ children }) => {
  const [role, setRole] = useState('customer'); // 'customer' | 'mechanic' | 'dispatch'
  const [user, setUser] = useState(() => {
    try {
      const saved = localStorage.getItem('mow_user');
      return saved ? JSON.parse(saved) : null;
    } catch (e) {
      return null;
    }
  });
  const [mongoStatus, setMongoStatus] = useState({
    connected: false,
    status: 'checking',
    uri: 'mongodb://127.0.0.1:27017/mech_on_wheels',
    databaseName: 'mech_on_wheels'
  });
  const [currentRequest, setCurrentRequest] = useState(null);
  const [requestsList, setRequestsList] = useState([]);
  const [quotesList, setQuotesList] = useState([]);
  const [mechanicsList, setMechanicsList] = useState([]);
  const [stats, setStats] = useState(null);
  const [socket, setSocket] = useState(null);
  const [notification, setNotification] = useState(null);
  const [isInvoiceOpen, setIsInvoiceOpen] = useState(false);
  const [isMongoModalOpen, setIsMongoModalOpen] = useState(false);
  const [isHowItWorksOpen, setIsHowItWorksOpen] = useState(false);

  // Initialize Socket.io
  useEffect(() => {
    const newSocket = io('http://localhost:5000', {
      transports: ['websocket', 'polling'],
      reconnectionAttempts: 10
    });

    setSocket(newSocket);

    newSocket.on('connect', () => {
      console.log('Connected to Mech On Wheels WebSocket server');
    });

    newSocket.on('db_status_changed', (data) => {
      checkHealth();
    });

    newSocket.on('quotes_updated', (data) => {
      if (currentRequest && currentRequest._id === data.requestId) {
        setQuotesList(data.quotes);
      }
      showToast('New competitive quotation received from nearby mechanic!');
    });

    newSocket.on('quote_accepted', (data) => {
      setCurrentRequest(data.request);
      showToast(`Mechanic ${data.mechanic?.name || ''} accepted the assignment! Heading towards you.`);
    });

    newSocket.on('mechanic_location_update', (data) => {
      setCurrentRequest(prev => {
        if (!prev || prev._id !== data.requestId) return prev;
        return {
          ...prev,
          tracking: { ...prev.tracking, ...data.tracking }
        };
      });
    });

    newSocket.on('step_changed', (data) => {
      if (currentRequest && currentRequest._id === data.requestId) {
        setCurrentRequest(data.request);
      }
      refreshData();
    });

    newSocket.on('payment_completed', (data) => {
      if (currentRequest && currentRequest._id === data.requestId) {
        setCurrentRequest(data.request);
      }
      showToast('Payment successful! Tax invoice ready for download.');
    });

    return () => newSocket.close();
  }, [currentRequest?._id]);

  // Check health & MongoDB status
  const checkHealth = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/health');
      setMongoStatus(res.data.mongo);
    } catch (err) {
      setMongoStatus({
        connected: false,
        status: 'disconnected',
        uri: 'mongodb://127.0.0.1:27017/mech_on_wheels',
        error: 'Backend API offline or restarting'
      });
    }
  };

  // Fetch initial data
  const refreshData = async () => {
    try {
      checkHealth();
      const [reqsRes, mechsRes, statsRes] = await Promise.all([
        axios.get('http://localhost:5000/api/requests'),
        axios.get('http://localhost:5000/api/mechanics'),
        axios.get('http://localhost:5000/api/stats')
      ]);

      setRequestsList(reqsRes.data);
      setMechanicsList(mechsRes.data);
      setStats(statsRes.data);

      // Set active request if not already set
      if (!currentRequest && reqsRes.data.length > 0) {
        const active = reqsRes.data.find(r => r.status !== 'REVIEWED' && r.status !== 'CANCELLED') || reqsRes.data[0];
        setCurrentRequest(active);
        // Fetch its quotes
        if (active) {
          const quotesRes = await axios.get(`http://localhost:5000/api/requests/${active._id}/quotes`);
          setQuotesList(quotesRes.data);
        }
      } else if (currentRequest) {
        const updated = reqsRes.data.find(r => r._id === currentRequest._id);
        if (updated) setCurrentRequest(updated);
        const quotesRes = await axios.get(`http://localhost:5000/api/requests/${currentRequest._id}/quotes`);
        setQuotesList(quotesRes.data);
      }
    } catch (err) {
      console.error('Error refreshing data:', err);
    }
  };

  useEffect(() => {
    refreshData();
    const interval = setInterval(refreshData, 6000);
    return () => clearInterval(interval);
  }, []);

  // Show Toast
  const showToast = (message, type = 'info') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 4000);
  };

  // Connect MongoDB
  const connectMongoDB = async (uri) => {
    try {
      const res = await axios.post('http://localhost:5000/api/connect-db', { uri });
      showToast('Connected to MongoDB successfully!', 'success');
      await checkHealth();
      return res.data;
    } catch (err) {
      showToast(err.response?.data?.error || 'Failed to connect to MongoDB', 'error');
      throw err;
    }
  };

  // Create Request
  const createServiceRequest = async (formData) => {
    try {
      const res = await axios.post('http://localhost:5000/api/requests', formData);
      setCurrentRequest(res.data.request);
      setQuotesList(res.data.quotes);
      showToast('Roadside breakdown request submitted! Nearby mechanics alerted.', 'success');
      return res.data;
    } catch (err) {
      showToast('Failed to submit request', 'error');
      throw err;
    }
  };

  // Accept Quote
  const acceptQuote = async (quoteId) => {
    if (!currentRequest) return;
    try {
      const res = await axios.post(`http://localhost:5000/api/requests/${currentRequest._id}/accept-quote`, { quoteId });
      setCurrentRequest(res.data.request);
      showToast('Assignment Confirmed! Mechanic is heading towards you.', 'success');
      return res.data;
    } catch (err) {
      showToast('Failed to accept quote', 'error');
      throw err;
    }
  };

  // Update Step
  const updateStep = async (step, status, details = {}) => {
    if (!currentRequest) return;
    try {
      const res = await axios.post(`http://localhost:5000/api/requests/${currentRequest._id}/update-step`, {
        step,
        status,
        details
      });
      setCurrentRequest(res.data);
      return res.data;
    } catch (err) {
      showToast('Failed to update status', 'error');
      throw err;
    }
  };

  // Update Mechanic GPS location
  const updateMechanicLocation = async (lat, lng, distanceKm, etaMinutes, routeProgress) => {
    if (!currentRequest) return;
    try {
      const res = await axios.post(`http://localhost:5000/api/requests/${currentRequest._id}/update-location`, {
        lat,
        lng,
        distanceKm,
        etaMinutes,
        routeProgress
      });
      setCurrentRequest(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  // Approve Estimate (Step 8)
  const approveEstimate = async (estimateData) => {
    if (!currentRequest) return;
    try {
      const res = await axios.post(`http://localhost:5000/api/requests/${currentRequest._id}/approve-estimate`, estimateData);
      setCurrentRequest(res.data);
      showToast('Transparent repair estimate approved! Repair in progress.', 'success');
      return res.data;
    } catch (err) {
      showToast('Failed to approve estimate', 'error');
      throw err;
    }
  };

  // Process Payment (Step 10)
  const processPayment = async (paymentData) => {
    if (!currentRequest) return;
    try {
      const res = await axios.post(`http://localhost:5000/api/requests/${currentRequest._id}/process-payment`, paymentData);
      setCurrentRequest(res.data);
      showToast('Payment successful! Invoice generated.', 'success');
      return res.data;
    } catch (err) {
      showToast('Payment processing failed', 'error');
      throw err;
    }
  };

  // Submit Review (Step 12)
  const submitReview = async (reviewData) => {
    if (!currentRequest) return;
    try {
      const res = await axios.post(`http://localhost:5000/api/requests/${currentRequest._id}/submit-review`, reviewData);
      setCurrentRequest(res.data);
      showToast('Thank you! Your rating and review has been submitted to MongoDB.', 'success');
      return res.data;
    } catch (err) {
      showToast('Failed to submit review', 'error');
      throw err;
    }
  };

  // Add Custom Quote (from mechanic side)
  const submitMechanicQuote = async (quoteData) => {
    try {
      const res = await axios.post('http://localhost:5000/api/quotes', quoteData);
      showToast('Quotation sent to vehicle owner successfully!', 'success');
      return res.data;
    } catch (err) {
      showToast('Failed to submit quotation', 'error');
      throw err;
    }
  };

  // Social Auth Login (Google First, Apple / iOS, Microsoft)
  const loginWithSocial = async (provider = 'google', customData = {}) => {
    try {
      const defaultProfiles = {
        google: {
          email: 'rohit.verma@gmail.com',
          name: 'Rohit Verma',
          avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=160&auto=format&fit=crop&q=80',
          role: role || 'customer',
          phone: '+91 98700 12345'
        },
        apple: {
          email: 'rohit.apple@icloud.com',
          name: 'Rohit Verma (Apple ID)',
          avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=160&auto=format&fit=crop&q=80',
          role: role || 'customer',
          phone: '+91 98700 12345'
        },
        microsoft: {
          email: 'rohit.verma@outlook.com',
          name: 'Rohit Verma (Microsoft)',
          avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=160&auto=format&fit=crop&q=80',
          role: role || 'customer',
          phone: '+91 98700 12345'
        }
      };

      const payload = {
        provider,
        ...(defaultProfiles[provider] || defaultProfiles.google),
        ...customData
      };

      const res = await axios.post('http://localhost:5000/api/auth/social-login', payload);
      setUser(res.data.user);
      localStorage.setItem('mow_user', JSON.stringify(res.data.user));
      showToast(`Welcome ${res.data.user.name}! Signed in via ${provider.toUpperCase()}`, 'success');
      return res.data.user;
    } catch (err) {
      showToast('Authentication failed', 'error');
      throw err;
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('mow_user');
    showToast('Signed out successfully');
  };

  return (
    <AppContext.Provider
      value={{
        user,
        loginWithSocial,
        logout,
        role,
        setRole,
        mongoStatus,
        connectMongoDB,
        currentRequest,
        setCurrentRequest,
        requestsList,
        quotesList,
        mechanicsList,
        stats,
        socket,
        notification,
        showToast,
        createServiceRequest,
        acceptQuote,
        updateStep,
        updateMechanicLocation,
        approveEstimate,
        processPayment,
        submitReview,
        submitMechanicQuote,
        isInvoiceOpen,
        setIsInvoiceOpen,
        isMongoModalOpen,
        setIsMongoModalOpen,
        isHowItWorksOpen,
        setIsHowItWorksOpen,
        refreshData
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => useContext(AppContext);
