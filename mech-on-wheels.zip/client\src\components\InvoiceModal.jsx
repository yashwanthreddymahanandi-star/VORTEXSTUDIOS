import React from 'react';
import { useApp } from '../context/AppContext';
import { X, Printer, Download, CheckCircle, ShieldCheck, Wrench } from 'lucide-react';

export const InvoiceModal = () => {
  const { isInvoiceOpen, setIsInvoiceOpen, currentRequest } = useApp();

  if (!isInvoiceOpen) return null;

  const invoiceNumber = currentRequest?.payment?.invoiceNumber || 'INV-MOW-2026-8812';
  const currentDate = new Date().toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-[#0B1120] border border-slate-800 rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative">
        
        {/* Close Button */}
        <button
          onClick={() => setIsInvoiceOpen(false)}
          className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Invoice Printable Sheet */}
        <div className="bg-white text-slate-900 rounded-2xl p-6 shadow-inner print:p-0">
          
          {/* Invoice Header */}
          <div className="flex items-start justify-between pb-4 border-b border-slate-200">
            <div>
              <div className="flex items-center space-x-1.5 text-emerald-600 font-black text-lg">
                <Wrench className="w-5 h-5" />
                <span>MECH ON WHEELS</span>
              </div>
              <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">
                Tax Invoice & Roadside Assistance Receipt
              </p>
            </div>
            <div className="text-right">
              <span className="inline-block text-[10px] font-black uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
                PAID IN FULL
              </span>
              <div className="text-xs font-mono font-bold text-slate-700 mt-1">
                {invoiceNumber}
              </div>
            </div>
          </div>

          {/* Details Grid */}
          <div className="grid grid-cols-2 gap-4 py-4 border-b border-slate-200 text-xs">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-500 block">Customer</span>
              <strong className="text-slate-900 block">{currentRequest?.customerName || 'Rohit Verma'}</strong>
              <span className="text-slate-600 block">{currentRequest?.customerPhone || '+91 98700 12345'}</span>
              <span className="text-slate-600 block">
                {currentRequest?.vehicle?.make} {currentRequest?.vehicle?.model} ({currentRequest?.vehicle?.regNumber})
              </span>
            </div>

            <div className="text-right">
              <span className="text-[10px] uppercase font-bold text-slate-500 block">Assigned Mechanic</span>
              <strong className="text-slate-900 block">{currentRequest?.selectedMechanic?.name || 'Mech Pro'}</strong>
              <span className="text-slate-600 block">{currentRequest?.selectedMechanic?.shopName || 'Mech Pro Express'}</span>
              <span className="text-slate-600 block">Date: {currentDate}</span>
            </div>
          </div>

          {/* Itemized Table */}
          <div className="py-4 border-b border-slate-200">
            <div className="text-xs font-bold uppercase text-slate-500 mb-2">Itemized Breakdown</div>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-slate-700">
                <span>1. Roadside OBD-II Diagnostic & Labour</span>
                <span className="font-semibold text-slate-900">₹1,100.00</span>
              </div>
              <div className="flex justify-between text-slate-700">
                <span>2. Quality Spare Parts (OEM 60A Fuse & Wiring Connector)</span>
                <span className="font-semibold text-slate-900">₹500.00</span>
              </div>
              <div className="flex justify-between text-slate-700">
                <span>3. Applicable GST / Government Taxes (18%)</span>
                <span className="font-semibold text-slate-900">₹250.00</span>
              </div>
            </div>
          </div>

          {/* Total */}
          <div className="pt-3 flex justify-between items-center text-sm font-extrabold text-slate-900">
            <span>Total Paid (via UPI):</span>
            <span className="text-xl text-emerald-600 font-black">₹1,850.00</span>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between text-[10px] text-slate-500">
            <span className="flex items-center space-x-1 text-emerald-700 font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>30 Days Roadside Repair Warranty</span>
            </span>
            <span>Support: 1800-MECH-911</span>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="mt-5 flex items-center justify-end space-x-3">
          <button
            onClick={() => window.print()}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center space-x-1.5"
          >
            <Printer className="w-3.5 h-3.5 text-cyan-400" />
            <span>Print Receipt</span>
          </button>
          <button
            onClick={() => setIsInvoiceOpen(false)}
            className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
