import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { connectDB, connectionDetails } from './config/db.js';
import { store } from './data/store.js';
import { createApiRouter } from './routes/api.js';
import { registerSocketHandlers } from './socket/socketHandler.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);

// CORS configuration for React frontend
const allowedOrigins = [
  'http://localhost:5173',
  'http://127.0.0.1:5173',
  'http://localhost:3000',
  'http://127.0.0.1:3000',
  'http://localhost:5000'
];

app.use(cors({
  origin: (origin, callback) => {
    callback(null, true);
  },
  credentials: true
}));

app.use(express.json());

// Setup Socket.io
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

registerSocketHandlers(io);

// Mount API routes
app.use('/api', createApiRouter(io));

// Serve client dist if built
const clientDistPath = path.resolve(__dirname, '../client/dist');
app.use(express.static(clientDistPath));

app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api') || req.path.startsWith('/socket.io')) {
    return next();
  }
  res.sendFile(path.join(clientDistPath, 'index.html'), (err) => {
    if (err) {
      res.json({
        app: 'Mech On Wheels API',
        status: 'Running',
        mongoStatus: connectionDetails.status,
        endpoints: ['/api/health', '/api/requests', '/api/mechanics']
      });
    }
  });
});

const PORT = process.env.PORT || 5000;

// Connect to MongoDB & Start Server
const startServer = async () => {
  // Attempt MongoDB connection
  await connectDB();
  await store.seedMongoIfConnected();

  server.listen(PORT, () => {
    console.log(`\n======================================================`);
    console.log(`🚀 MECH ON WHEELS Full-Stack App running on port ${PORT}`);
    console.log(`🌐 Web App & API: http://localhost:${PORT}`);
    console.log(`📡 WebSocket ready on ws://localhost:${PORT}`);
    console.log(`🍃 MongoDB: ${connectionDetails.status.toUpperCase()}`);
    console.log(`======================================================\n`);
  });
};

startServer();
