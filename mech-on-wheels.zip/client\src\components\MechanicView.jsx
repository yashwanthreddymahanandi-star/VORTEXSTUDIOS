import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Wrench,
  Radio,
  Send,
  Navigation,
  CheckCircle,
  Clock,
  DollarSign,
  TrendingUp,
  MapPin,
  Car,
  AlertCircle,
  Phone,
  FileText,
  Star
} from 'lucide-react';

export const MechanicView = () => {
  const {
    currentRequest,
    submitMechanicQuote,
    updateStep,
    updateMechanicLocation,
    approveEstimate
  } = useApp();

  const [quotePrice, setQuotePrice] = useState(1850);
  const [etaMins, setEtaMins] = useState(8);
  const [quoteNote, setQuoteNote] = useState('Rapid response mobile unit with OBD-II diagnostic tools and OEM alternator fuses.');

  // Estimate bill builder
  const [serviceCharge, setServiceCharge] = useState(1100);
  const [partsCharge, setPartsCharge] = useState(500);
  const [taxes, setTaxes] = useState(250);

  const totalEstimate = Number(serviceCharge) + Number(partsCharge) + Number(taxes);

  // Active mechanic profile (matching Mech Pro from screenshot)
  const currentMechanic = {
    name: 'Rajesh Kumar (Mech Pro)',
    shop: 'Mech Pro Express Service',
    rating: 4.8,
    jobsCompleted: 28,
    vanPlate: 'DL 04 MP 1850',
    totalEarned: 34500,
    commissionRate: 0.05 // 5% minimal fee
  };

  const handleSendQuote = async (e) => {
    e.preventDefault();
    if (!currentRequest) return;
    await submitMechanicQuote({
      requestId: currentRequest._id,
      mechanicId: 'mech_001',
      mechanicName: 'Mech Pro',
      shopName: 'Mech Pro Express',
      avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=160&auto=format&fit=crop&q=80',
      rating: 4.8,
      price: Number(quotePrice),
      distanceKm: 2.4,
      etaMinutes: Number(etaMins),
      breakdownNote: quoteNote
    });
  };

  return (
    <div className="space-y-6">
      
      {/* Mechanic Header Profile Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1560250097-0b93528c311a?w=160&auto=format&fit=crop&q=80"
              alt="Mechanic"
              className="w-14 h-14 rounded-2xl object-cover border-2 border-cyan-500 shadow-md"
            />
            <span className="w-3.5 h-3.5 rounded-full bg-emerald-500 absolute -bottom-1 -right-1 border-2 border-slate-950"></span>
          </div>

          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-lg font-bold text-white">{currentMechanic.name}</h2>
              <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                Verified Pro
              </span>
            </div>
            <div className="flex items-center space-x-3 text-xs text-slate-400 mt-1">
              <span className="text-slate-300 font-medium">{currentMechanic.shop}</span>
              <span>•</span>
              <span className="flex items-center space-x-1 text-amber-400 font-bold">
                <Star className="w-3 h-3 fill-current" />
                <span>{currentMechanic.rating} (148 reviews)</span>
              </span>
              <span>•</span>
              <span className="text-cyan-400 font-medium">Van: {currentMechanic.vanPlate}</span>
            </div>
          </div>
        </div>

        {/* Mechanic Quick Stats */}
        <div className="flex items-center space-x-4 bg-slate-950/80 px-4 py-2.5 rounded-xl border border-slate-800">
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-400">Total Earnings</div>
            <div className="text-lg font-black text-emerald-400">₹{currentMechanic.totalEarned.toLocaleString()}</div>
          </div>
          <div className="h-8 w-px bg-slate-800"></div>
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-400">Commission Fee</div>
            <div className="text-lg font-black text-cyan-400">5% <span className="text-[10px] text-slate-400">(Minimal)</span></div>
          </div>
          <div className="h-8 w-px bg-slate-800"></div>
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-400">Jobs Done</div>
            <div className="text-lg font-black text-white">{currentMechanic.jobsCompleted}</div>
          </div>
        </div>
      </div>

      {/* Incoming Breakdown Radar / Alert Card (Step 1 of Mechanic flow) */}
      <div className="bg-gradient-to-r from-cyan-950/30 via-slate-900 to-slate-900 border border-cyan-500/30 rounded-2xl p-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-2 mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-black">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-lg font-bold text-white">Breakdown Radar Alert</h3>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              </div>
              <p className="text-xs text-slate-400">
                Driver broke down nearby. Send competitive quote and arrival estimate instantly.
              </p>
            </div>
          </div>
          <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
            2.4 km from your Mobile Van
          </span>
        </div>

        {/* Breakdown Driver Info Summary */}
        <div className="bg-slate-950/80 rounded-xl p-4 border border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-4 mb-5 text-xs">
          <div>
            <span className="text-slate-400 block mb-0.5">Driver & Vehicle:</span>
            <span className="font-bold text-white text-sm">
              {currentRequest?.customerName || 'Rohit Verma'} • {currentRequest?.vehicle?.make} {currentRequest?.vehicle?.model}
            </span>
            <span className="text-slate-400 block font-mono text-[11px] mt-0.5">
              Plate: {currentRequest?.vehicle?.regNumber || 'DL 08 CD 4455'}
            </span>
          </div>

          <div>
            <span className="text-slate-400 block mb-0.5">Location:</span>
            <span className="font-bold text-emerald-400 text-sm flex items-center space-x-1">
              <MapPin className="w-3.5 h-3.5" />
              <span>{currentRequest?.location?.address || 'NH 44, Near Exit 123'}</span>
            </span>
            <span className="text-slate-400 block text-[11px] mt-0.5">
              {currentRequest?.location?.landmark || 'Milepost 123 Flyover'}
            </span>
          </div>

          <div>
            <span className="text-slate-400 block mb-0.5">Reported Issue:</span>
            <span className="font-bold text-rose-400 text-sm">
              {currentRequest?.issue?.category || 'Engine Breakdown'}
            </span>
            <span className="text-slate-400 block text-[11px] mt-0.5 truncate">
              {currentRequest?.issue?.description || 'Car stalled abruptly with battery light'}
            </span>
          </div>
        </div>

        {/* Send Quotation Form */}
        <form onSubmit={handleSendQuote} className="grid grid-cols-1 sm:grid-cols-4 gap-4 items-end">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Price Estimate (₹)
            </label>
            <div className="relative">
              <input
                type="number"
                value={quotePrice}
                onChange={(e) => setQuotePrice(e.target.value)}
                required
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-bold pl-7 focus:outline-none focus:border-cyan-500"
              />
              <span className="absolute left-3 top-2.5 text-xs text-slate-400 font-bold">₹</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Arrival Window (Mins)
            </label>
            <div className="relative">
              <input
                type="number"
                value={etaMins}
                onChange={(e) => setEtaMins(e.target.value)}
                required
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-bold pl-8 focus:outline-none focus:border-cyan-500"
              />
              <Clock className="w-4 h-4 text-slate-400 absolute left-2.5 top-2.5" />
            </div>
          </div>

          <div className="sm:col-span-1">
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Equipment / Van Notes
            </label>
            <input
              type="text"
              value={quoteNote}
              onChange={(e) => setQuoteNote(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/20 flex items-center justify-center space-x-1.5 transition-all"
            >
              <Send className="w-3.5 h-3.5" />
              <span>SEND QUOTATION</span>
            </button>
          </div>
        </form>
      </div>

      {/* Active Job Progression Controller */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-5">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black">
              <Wrench className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Active Job Management</h3>
              <p className="text-xs text-slate-400">
                Control the real-time job steps from dispatch to repair completion
              </p>
            </div>
          </div>

          <span className="text-xs font-extrabold uppercase px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            Current Stage: Step {currentRequest?.currentStep || 2}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          
          {/* Phase A: Driving & Arrival */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
              <Navigation className="w-4 h-4 text-cyan-400" />
              <span>1. Van Navigation</span>
            </h4>
            <p className="text-xs text-slate-400">
              Start driving towards NH 44, Near Exit 123 with live GPS updates.
            </p>
            <div className="space-y-2">
              <button
                onClick={() => {
                  updateStep(6, 'EN_ROUTE');
                  updateMechanicLocation(28.6210, 77.2140, 2.4, 8, 30);
                }}
                className="w-full py-2 rounded-lg bg-cyan-600/30 hover:bg-cyan-600/40 text-cyan-300 text-xs font-bold border border-cyan-500/40"
              >
                Mark "Heading to Location"
              </button>
              <button
                onClick={() => {
                  updateMechanicLocation(28.6139, 77.2090, 0, 0, 100);
                  updateStep(7, 'ARRIVED');
                }}
                className="w-full py-2 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/40 text-emerald-300 text-xs font-bold border border-emerald-500/40"
              >
                Mark "Arrived on Site"
              </button>
            </div>
          </div>

          {/* Phase B: Diagnosis & Transparent Itemized Bill */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
              <FileText className="w-4 h-4 text-amber-400" />
              <span>2. Transparent Estimate</span>
            </h4>
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Service:</span>
                <input
                  type="number"
                  value={serviceCharge}
                  onChange={(e) => setServiceCharge(Number(e.target.value))}
                  className="w-20 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-right font-bold text-white"
                />
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Parts:</span>
                <input
                  type="number"
                  value={partsCharge}
                  onChange={(e) => setPartsCharge(Number(e.target.value))}
                  className="w-20 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-right font-bold text-white"
                />
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Taxes:</span>
                <input
                  type="number"
                  value={taxes}
                  onChange={(e) => setTaxes(Number(e.target.value))}
                  className="w-20 bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-right font-bold text-white"
                />
              </div>
              <div className="flex justify-between pt-1 border-t border-slate-800 font-bold text-emerald-400">
                <span>Total:</span>
                <span>₹{totalEstimate}</span>
              </div>
            </div>
            <button
              onClick={() => {
                approveEstimate({ serviceCharge, parts: partsCharge, taxes });
                updateStep(8, 'ESTIMATE_PENDING');
              }}
              className="w-full py-2 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-bold border border-amber-500/40"
            >
              Submit Itemized Estimate (Step 8)
            </button>
          </div>

          {/* Phase C: Repair & Complete */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>3. Repair & Settlement</span>
            </h4>
            <p className="text-xs text-slate-400">
              Complete on-site repair using genuine parts and request digital customer payment.
            </p>
            <div className="space-y-2">
              <button
                onClick={() => updateStep(9, 'REPAIR_IN_PROGRESS')}
                className="w-full py-2 rounded-lg bg-cyan-600/30 hover:bg-cyan-600/40 text-cyan-300 text-xs font-bold border border-cyan-500/40"
              >
                Mark "Repair in Progress" (Step 9)
              </button>
              <button
                onClick={() => updateStep(10, 'PAYMENT_PENDING')}
                className="w-full py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-extrabold shadow-md"
              >
                Repair Done! Request Payment (Step 10)
              </button>
            </div>
          </div>

        </div>
      </div>

    </div>
  );
};
