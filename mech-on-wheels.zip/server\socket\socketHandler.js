export const registerSocketHandlers = (io) => {
  io.on('connection', (socket) => {
    console.log(`⚡ Client connected: ${socket.id}`);

    // Join room for specific breakdown request
    socket.on('join_breakdown', (requestId) => {
      socket.join(`breakdown_${requestId}`);
      console.log(`Socket ${socket.id} joined room breakdown_${requestId}`);
    });

    // Send chat message between driver and mechanic
    socket.on('send_message', (data) => {
      // { requestId, sender: 'driver'|'mechanic', text, time }
      io.to(`breakdown_${data.requestId}`).emit('new_message', data);
      io.emit('global_message_notification', data);
    });

    // Mechanic simulated GPS live route movement
    socket.on('update_live_gps', (data) => {
      // { requestId, lat, lng, distanceKm, etaMinutes, routeProgress }
      io.emit('mechanic_location_update', data);
    });

    // Mechanic updates repair status
    socket.on('update_job_status', (data) => {
      io.emit('step_changed', data);
    });

    socket.on('disconnect', () => {
      console.log(`🔌 Client disconnected: ${socket.id}`);
    });
  });
};
