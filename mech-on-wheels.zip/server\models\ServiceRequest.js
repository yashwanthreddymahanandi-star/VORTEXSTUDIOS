import mongoose from 'mongoose';

const serviceRequestSchema = new mongoose.Schema(
  {
    customerName: { type: String, required: true },
    customerPhone: { type: String, required: true },
    customerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },

    vehicle: {
      make: { type: String, required: true },
      model: { type: String, required: true },
      year: { type: String, default: '2023' },
      regNumber: { type: String, required: true },
      type: { type: String, enum: ['Car', 'SUV', 'Bike', 'Van', 'Truck'], default: 'Car' }
    },

    location: {
      address: { type: String, required: true },
      landmark: { type: String, default: 'Near Highway Milepost 44' },
      lat: { type: Number, default: 28.6139 },
      lng: { type: Number, default: 77.2090 }
    },

    issue: {
      category: {
        type: String,
        enum: [
          'Engine Breakdown',
          'Flat Tyre',
          'Battery Jumpstart',
          'Overheating',
          'Brake Failure',
          'Fuel Delivery',
          'Locked Out',
          'Towing',
          'General Electrical'
        ],
        required: true
      },
      description: { type: String, default: '' },
      severity: { type: String, enum: ['Urgent (High)', 'Moderate', 'Low'], default: 'Urgent (High)' },
      symptoms: [{ type: String }]
    },

    status: {
      type: String,
      enum: [
        'REQUEST_SUBMITTED',     // Step 2: Open app & request service
        'QUOTES_RECEIVED',      // Step 3: Seen by mechanics, quotes received
        'QUOTE_ACCEPTED',       // Step 4: Driver chooses best option
        'ASSIGNED',             // Step 5: Assignment confirmed
        'EN_ROUTE',             // Step 6: Mechanic driving to location (real-time tracking)
        'ARRIVED',              // Step 7: On-site diagnosis begins
        'ESTIMATE_PENDING',     // Step 8: Itemized transparent quote submitted
        'REPAIR_IN_PROGRESS',   // Step 9: Customer approved, repair underway
        'PAYMENT_PENDING',      // Step 10: Repair complete, bill ready
        'PAID',                 // Step 10: Secure payment finished, invoice generated
        'COMPLETED',            // Step 11: Get back on the road
        'REVIEWED',             // Step 12: Customer rated & reviewed
        'CANCELLED'
      ],
      default: 'REQUEST_SUBMITTED'
    },

    currentStep: { type: Number, default: 2 }, // 1 to 12 matching infographic

    selectedMechanic: {
      mechanicId: { type: String, default: null },
      name: { type: String, default: '' },
      shopName: { type: String, default: '' },
      phone: { type: String, default: '' },
      rating: { type: Number, default: 4.8 },
      avatar: { type: String, default: '' },
      vanModel: { type: String, default: 'Mech Mobile Express Van' }
    },

    tracking: {
      mechanicLat: { type: Number, default: 28.6250 },
      mechanicLng: { type: Number, default: 77.2180 },
      driverLat: { type: Number, default: 28.6139 },
      driverLng: { type: Number, default: 77.2090 },
      distanceKm: { type: Number, default: 2.4 },
      etaMinutes: { type: Number, default: 8 },
      routeProgress: { type: Number, default: 0 }, // 0 to 100%
      speedKmh: { type: Number, default: 42 }
    },

    estimate: {
      serviceCharge: { type: Number, default: 1100 },
      parts: { type: Number, default: 500 },
      taxes: { type: Number, default: 250 },
      totalAmount: { type: Number, default: 1850 },
      notes: { type: String, default: 'Complete alternator check, wiring harness fix, on-site fuse replacement' },
      approvedByCustomer: { type: Boolean, default: false },
      approvedAt: { type: Date, default: null }
    },

    payment: {
      amount: { type: Number, default: 1850 },
      status: { type: String, enum: ['Pending', 'Successful'], default: 'Pending' },
      method: { type: String, default: 'UPI' },
      invoiceNumber: { type: String, default: '' },
      transactionId: { type: String, default: '' },
      paidAt: { type: Date, default: null }
    },

    review: {
      rating: { type: Number, default: 0 }, // 1 to 5
      feedback: { type: String, default: '' },
      tags: [{ type: String }],
      createdAt: { type: Date, default: null }
    }
  },
  { timestamps: true }
);

export const ServiceRequest = mongoose.model('ServiceRequest', serviceRequestSchema);
export default ServiceRequest;
