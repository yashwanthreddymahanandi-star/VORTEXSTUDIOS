/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          dark: '#070C18',
          card: '#0F172A',
          border: '#1E293B',
          green: '#22C55E',
          accent: '#06B6D4',
          orange: '#F97316'
        }
      }
    },
  },
  plugins: [],
}
