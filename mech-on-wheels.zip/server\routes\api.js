import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { store } from '../data/store.js';
import { connectDB, connectionDetails, isMongoConnected } from '../config/db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const createApiRouter = (io) => {
  const router = express.Router();

  // 1. Health & MongoDB status
  router.get('/health', (req, res) => {
    res.json({
      status: 'online',
      service: 'Mech On Wheels Backend API',
      timestamp: new Date().toISOString(),
      mongo: {
        connected: isMongoConnected,
        status: connectionDetails.status,
        uri: connectionDetails.uri.replace(/:([^:@]{4})[^:@]*@/, ':****@'), // mask passwords
        databaseName: connectionDetails.databaseName,
        error: connectionDetails.error
      }
    });
  });

  // Download ZIP endpoint
  router.get('/download-zip', (req, res) => {
    const zipPath = path.resolve(__dirname, '../../mech-on-wheels.zip');
    if (fs.existsSync(zipPath)) {
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="mech-on-wheels.zip"');
      return res.sendFile(zipPath);
    } else {
      return res.status(404).json({ error: 'ZIP file not generated yet. Please run node create-zip.js' });
    }
  });

  // Social Login (Google First, Apple / iOS, Microsoft)
  router.post('/auth/social-login', async (req, res) => {
    try {
      const { provider, email, name, avatar, role, phone } = req.body;
      if (!email) {
        return res.status(400).json({ error: 'Email is required for sign in' });
      }

      const user = await store.findOrCreateUser({
        provider: provider || 'google',
        email,
        name: name || email.split('@')[0],
        avatar,
        role: role || 'customer',
        phone: phone || '+91 98000 00000'
      });

      res.json({
        success: true,
        message: `Signed in successfully with ${provider?.toUpperCase() || 'GOOGLE'}!`,
        user,
        token: 'jwt_mock_token_' + Date.now()
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // 2. Connect or update MongoDB URI live
  router.post('/connect-db', async (req, res) => {
    const { uri } = req.body;
    if (!uri) {
      return res.status(400).json({ error: 'MongoDB URI is required' });
    }
    const result = await connectDB(uri);
    if (result.success) {
      await store.seedMongoIfConnected();
      io.emit('db_status_changed', { connected: true, uri: result.host });
      return res.json({
        success: true,
        message: 'Successfully connected to MongoDB!',
        details: result
      });
    } else {
      return res.status(500).json({
        success: false,
        message: 'Failed to connect to MongoDB',
        error: result.error
      });
    }
  });

  // 3. Get all mechanics
  router.get('/mechanics', async (req, res) => {
    try {
      const mechanics = await store.getMechanics();
      res.json(mechanics);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // 4. Get all requests
  router.get('/requests', async (req, res) => {
    try {
      const requests = await store.getRequests();
      res.json(requests);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // 5. Get request by ID
  router.get('/requests/:id', async (req, res) => {
    try {
      const request = await store.getRequestById(req.params.id);
      if (!request) return res.status(404).json({ error: 'Request not found' });
      const quotes = await store.getQuotesForRequest(req.params.id);
      res.json({ request, quotes });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // 6. Create service request (Step 2: Request breakdown service)
  router.post('/requests', async (req, res) => {
    try {
      const result = await store.createRequest(req.body);
      // Real-time broadcast to all connected mechanics & admins
      io.emit('new_breakdown_request', result.request);
      io.emit('quotes_updated', { requestId: result.request._id, quotes: result.quotes });
      res.status(201).json(result);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // 7. Get quotes for request
  router.get('/requests/:id/quotes', async (req, res) => {
    try {
      const quotes = await store.getQuotesForRequest(req.params.id);
      res.json(quotes);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // 8. Mechanic submits quotation (Step 3: Send quotation)
  router.post('/quotes', async (req, res) => {
    try {
      const newQuote = await store.addQuote(req.body);
      io.emit('quote_received', newQuote);
      const allQuotes = await store.getQuotesForRequest(req.body.requestId);
      io.emit('quotes_updated', { requestId: req.body.requestId, quotes: allQuotes });
      res.status(201).json(newQuote);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // 9. Customer accepts quote (Step 4 & 5: Choose best option & assignment confirmed)
  router.post('/requests/:id/accept-quote', async (req, res) => {
    try {
      const { quoteId } = req.body;
      const result = await store.acceptQuote(req.params.id, quoteId);
      io.emit('quote_accepted', {
        requestId: req.params.id,
        quoteId,
        request: result.request,
        mechanic: result.request.selectedMechanic
      });
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // 10. Update tracking / Mechanic location (Step 6: Live GPS tracking)
  router.post('/requests/:id/update-location', async (req, res) => {
    try {
      const { lat, lng, distanceKm, etaMinutes, routeProgress } = req.body;
      const updated = await store.updateRequestStep(req.params.id, 6, 'EN_ROUTE', {
        tracking: {
          mechanicLat: lat,
          mechanicLng: lng,
          distanceKm: distanceKm !== undefined ? distanceKm : 2.4,
          etaMinutes: etaMinutes !== undefined ? etaMinutes : 8,
          routeProgress: routeProgress !== undefined ? routeProgress : 50
        }
      });
      io.emit('mechanic_location_update', {
        requestId: req.params.id,
        tracking: updated.tracking
      });
      res.json(updated);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // 11. Advance step / status
  router.post('/requests/:id/update-step', async (req, res) => {
    try {
      const { step, status, details } = req.body;
      const updated = await store.updateRequestStep(req.params.id, step, status, details || {});
      io.emit('step_changed', {
        requestId: req.params.id,
        step,
        status,
        request: updated
      });
      res.json(updated);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // 12. Transparent Pricing approval (Step 8: Approve before repair begins)
  router.post('/requests/:id/approve-estimate', async (req, res) => {
    try {
      const { serviceCharge, parts, taxes, notes } = req.body;
      const totalAmount = (serviceCharge || 1100) + (parts || 500) + (taxes || 250);
      const updated = await store.updateRequestStep(req.params.id, 9, 'REPAIR_IN_PROGRESS', {
        estimate: {
          serviceCharge: serviceCharge || 1100,
          parts: parts || 500,
          taxes: taxes || 250,
          totalAmount,
          notes: notes || 'Roadside repair estimate confirmed',
          approvedByCustomer: true,
          approvedAt: new Date()
        },
        payment: {
          amount: totalAmount,
          status: 'Pending'
        }
      });
      io.emit('estimate_approved', { requestId: req.params.id, request: updated });
      res.json(updated);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // 13. Process Payment (Step 10: Pay securely in-app)
  router.post('/requests/:id/process-payment', async (req, res) => {
    try {
      const { method, amount } = req.body;
      const invoiceNumber = 'INV-MOW-2026-' + Math.floor(1000 + Math.random() * 9000);
      const transactionId = 'TXN_' + Date.now().toString(36).toUpperCase();

      const updated = await store.updateRequestStep(req.params.id, 11, 'COMPLETED', {
        payment: {
          amount: amount || 1850,
          status: 'Successful',
          method: method || 'UPI',
          invoiceNumber,
          transactionId,
          paidAt: new Date()
        }
      });
      io.emit('payment_completed', {
        requestId: req.params.id,
        request: updated,
        invoiceNumber,
        transactionId
      });
      res.json(updated);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // 14. Submit Review & Rating (Step 12: Rate & review experience)
  router.post('/requests/:id/submit-review', async (req, res) => {
    try {
      const { rating, feedback, tags } = req.body;
      const updated = await store.updateRequestStep(req.params.id, 12, 'REVIEWED', {
        review: {
          rating: Number(rating) || 5,
          feedback: feedback || 'Great service! Fixed quickly on the spot.',
          tags: tags || ['Quick Response', 'Professional Mechanic', 'Fair Price'],
          createdAt: new Date()
        }
      });
      io.emit('review_submitted', { requestId: req.params.id, request: updated });
      res.json(updated);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // 15. Operational statistics
  router.get('/stats', async (req, res) => {
    try {
      const requests = await store.getRequests();
      const mechanics = await store.getMechanics();
      const completed = requests.filter(r => r.status === 'COMPLETED' || r.status === 'REVIEWED').length;
      const active = requests.filter(r => r.status !== 'COMPLETED' && r.status !== 'REVIEWED' && r.status !== 'CANCELLED').length;
      const totalRevenue = requests.reduce((acc, r) => acc + (r.payment?.status === 'Successful' ? r.payment.amount : 0), 0);

      res.json({
        totalRequests: requests.length,
        activeBreakdowns: active,
        completedRepairs: completed,
        totalMechanics: mechanics.length,
        averageRating: 4.8,
        totalRevenue,
        avgResponseMinutes: 12
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  return router;
};
