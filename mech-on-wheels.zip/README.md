# 🚗 MECH ON WHEELS (Mech On) - Full-Stack MERN Platform
> *"YOUR CAR BREAKS DOWN. WE GET YOU BACK ON TRACK."*

A production-grade **MERN (MongoDB, Express, React, Node.js)** roadside assistance platform matching the 12-step on-demand breakdown workflow.

---

## 🌟 Key Features & Workflow Architecture

### 1. Dual Persona Ecosystem (Image 1)
- **For Vehicle Owners:**
  1. *Raise a Request:* Share breakdown location (auto GPS or custom landmark), vehicle details & issue.
  2. *Compare Competitive Quotes:* Nearby verified mechanics submit transparent pricing & ETAs (Mech Pro, FixIt Auto, Speedy Service).
  3. *Repair & Continue:* Select preferred quote, track live mechanic GPS van on highway route, approve transparent estimate, pay securely, and rate the service.
- **For Local Mechanics:**
  1. *Receive Alerts:* Instant radar notifications when drivers break down nearby.
  2. *Send Quotation:* Submit transparent price estimate & arrival window instantly.
  3. *Grow Your Income:* Complete on-site repairs with minimal platform commission (5%).

### 2. Complete 12-Step Lifecycle (Image 2)
1. **Vehicle Breakdown:** Safety tips & instant SOS breakdown broadcast.
2. **Open App & Request Service:** Location (NH 44, Exit 123) + vehicle details + issue category.
3. **Request Seen by Multiple Mechanics:** Quotes from Mech Pro (₹1,850, 4.8★), FixIt Auto (₹2,150, 4.6★), Speedy Service (₹2,400, 4.7★).
4. **Choose Best Option:** Compare ratings, arrival time, pricing side-by-side.
5. **Assignment Confirmed:** Mechanic accepts callout.
6. **Track Mechanic in Real-Time:** Interactive vector road map with live mechanic van moving along NH 44 and ETA updates.
7. **On-Site Diagnosis & Repair:** Mechanic reaches location, performs inspection.
8. **Transparent Pricing:** Itemized billing (Service ₹1,100, Parts ₹500, Taxes ₹250 = ₹1,850) with customer approval prior to repair.
9. **Repair in Progress:** On-site repair status with genuine parts.
10. **Pay Securely In-App:** UPI / Card / Cash checkout with instant printable tax invoice.
11. **Get Back on the Road:** Peace of mind completion banner.
12. **Rate & Review Experience:** 5-star rating, compliment tags, and written feedback stored in MongoDB.

---

## 🍃 MongoDB Connection & Persistence

The backend connects directly to MongoDB via **Mongoose**.

- **Default URI:** `mongodb://127.0.0.1:27017/mech_on_wheels`
- **MongoDB Atlas Support:** In the UI, click the **MongoDB Status** pill in the top navigation bar to input your MongoDB Atlas connection string (`mongodb+srv://...`) and test the connection live!
- **Zero-Crash Resilient Architecture:** If MongoDB is not currently running locally, the server operates with an in-memory storage engine and syncs automatically when MongoDB connects.

### Mongoose Models
- `User`: Mechanic profiles, ratings, vehicle info, earnings.
- `ServiceRequest`: Breakdown details, 12-step status progression, itemized bill, payment, and review.
- `Quote`: Competitive bids submitted by nearby mechanics.

---

## 🚀 How to Run

### Option A: Run Full App (Backend + Built React Client)
```bash
cd server
npm start
```
Open **`http://localhost:5000`** in your browser.

### Option B: Run in Development Mode
1. **Start Backend API:**
```bash
cd server
npm start
```
(Runs on `http://localhost:5000`)

2. **Start Frontend (Vite React):**
```bash
cd client
npm run dev
```
(Runs on `http://localhost:5173`)
