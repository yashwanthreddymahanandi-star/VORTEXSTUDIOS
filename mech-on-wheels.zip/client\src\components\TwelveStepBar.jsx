import React from 'react';
import { useApp } from '../context/AppContext';
import {
  AlertTriangle,
  Smartphone,
  Radio,
  CheckCircle2,
  Navigation,
  Search,
  Receipt,
  Wrench,
  CreditCard,
  ThumbsUp,
  Star,
  Check
} from 'lucide-react';

export const STEPS_CONFIG = [
  { step: 1, title: 'Breakdown', sub: 'Safety Alert', icon: AlertTriangle, status: 'VEHICLE_BREAKDOWN' },
  { step: 2, title: 'Request Service', sub: 'Details & GPS', icon: Smartphone, status: 'REQUEST_SUBMITTED' },
  { step: 3, title: 'Seen by Mechanics', sub: 'Quotes Sent', icon: Radio, status: 'QUOTES_RECEIVED' },
  { step: 4, title: 'Choose Option', sub: 'Compare Prices', icon: CheckCircle2, status: 'QUOTE_ACCEPTED' },
  { step: 5, title: 'Assignment', sub: 'Confirmed', icon: Check, status: 'ASSIGNED' },
  { step: 6, title: 'Track Real-Time', sub: 'Live Van GPS', icon: Navigation, status: 'EN_ROUTE' },
  { step: 7, title: 'On-site Diagnosis', sub: 'Inspection', icon: Search, status: 'ARRIVED' },
  { step: 8, title: 'Transparent Price', sub: 'Approve Estimate', icon: Receipt, status: 'ESTIMATE_PENDING' },
  { step: 9, title: 'Repair in Progress', sub: 'Quality Parts', icon: Wrench, status: 'REPAIR_IN_PROGRESS' },
  { step: 10, title: 'Pay In-App', sub: 'Instant Invoice', icon: CreditCard, status: 'PAYMENT_PENDING' },
  { step: 11, title: 'Back on Road', sub: 'Peace of Mind', icon: ThumbsUp, status: 'COMPLETED' },
  { step: 12, title: 'Rate & Review', sub: 'Feedback', icon: Star, status: 'REVIEWED' }
];

export const TwelveStepBar = () => {
  const { currentRequest, updateStep } = useApp();
  const currentStep = currentRequest?.currentStep || 2;

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 my-4 shadow-xl overflow-x-auto">
      <div className="flex items-center justify-between mb-3 px-1">
        <div className="flex items-center space-x-2">
          <span className="flex items-center justify-center w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-black">
            12
          </span>
          <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
            Breakdown Assistance Lifecycle
          </h3>
        </div>
        <div className="text-xs font-semibold text-slate-400">
          Step <span className="text-emerald-400 font-bold">{currentStep}</span> of 12: {' '}
          <span className="text-slate-200">{STEPS_CONFIG[currentStep - 1]?.title}</span>
        </div>
      </div>

      {/* Horizontal step tracker */}
      <div className="min-w-[950px] flex items-center justify-between relative py-2">
        {/* Background track line */}
        <div className="absolute top-1/2 left-4 right-4 h-1 bg-slate-800 -translate-y-1/2 z-0" />
        
        {/* Active progress bar line */}
        <div
          className="absolute top-1/2 left-4 h-1 bg-gradient-to-r from-emerald-500 to-cyan-400 -translate-y-1/2 z-0 transition-all duration-500"
          style={{ width: `${((currentStep - 1) / 11) * 96}%` }}
        />

        {STEPS_CONFIG.map((s) => {
          const Icon = s.icon;
          const isPassed = currentStep > s.step;
          const isCurrent = currentStep === s.step;

          return (
            <button
              key={s.step}
              onClick={() => updateStep(s.step, s.status)}
              className="relative z-10 flex flex-col items-center group focus:outline-none"
              title={`Jump to Step ${s.step}: ${s.title}`}
            >
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-300 shadow-lg ${
                  isCurrent
                    ? 'bg-emerald-500 text-slate-950 ring-4 ring-emerald-500/30 scale-110 font-black'
                    : isPassed
                    ? 'bg-slate-800 border-2 border-emerald-500 text-emerald-400 hover:bg-slate-700'
                    : 'bg-slate-800/80 border border-slate-700 text-slate-500 hover:border-slate-500 hover:text-slate-300'
                }`}
              >
                {isPassed ? <Check className="w-4 h-4 stroke-[3]" /> : <Icon className="w-4 h-4" />}
              </div>

              <div className="mt-2 text-center">
                <span
                  className={`block text-[11px] font-bold tracking-tight whitespace-nowrap ${
                    isCurrent
                      ? 'text-emerald-400'
                      : isPassed
                      ? 'text-slate-300'
                      : 'text-slate-500'
                  }`}
                >
                  {s.step}. {s.title}
                </span>
                <span className="block text-[9px] text-slate-400 font-medium whitespace-nowrap">
                  {s.sub}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
