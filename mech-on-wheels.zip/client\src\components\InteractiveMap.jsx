import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Navigation, Play, Pause, FastForward, CheckCircle, MapPin, Compass } from 'lucide-react';

export const InteractiveMap = () => {
  const { currentRequest, updateMechanicLocation, updateStep } = useApp();
  const [isSimulating, setIsSimulating] = useState(false);
  const [speedMultiplier, setSpeedMultiplier] = useState(1);

  const routeProgress = currentRequest?.tracking?.routeProgress || 25;
  const distanceKm = currentRequest?.tracking?.distanceKm !== undefined ? currentRequest.tracking.distanceKm : 2.4;
  const etaMinutes = currentRequest?.tracking?.etaMinutes !== undefined ? currentRequest.tracking.etaMinutes : 8;

  // Van coordinates along a curved highway path from (120, 80) to (580, 290)
  // Parametric Bezier curve formula
  const getCoordinatesAlongPath = (t) => {
    // P0: Start (120, 80) - Mechanic Shop
    // P1: Control Point 1 (280, 50)
    // P2: Control Point 2 (400, 320)
    // P3: End (620, 260) - Breakdown Car
    const p0 = { x: 120, y: 90 };
    const p1 = { x: 280, y: 60 };
    const p2 = { x: 420, y: 310 };
    const p3 = { x: 620, y: 260 };

    const u = 1 - t;
    const tt = t * t;
    const uu = u * u;
    const uuu = uu * u;
    const ttt = tt * t;

    const x = uuu * p0.x + 3 * uu * t * p1.x + 3 * u * tt * p2.x + ttt * p3.x;
    const y = uuu * p0.y + 3 * uu * t * p1.y + 3 * u * tt * p2.y + ttt * p3.y;

    // Calculate tangent angle for van rotation
    const dx = 3 * uu * (p1.x - p0.x) + 6 * u * t * (p2.x - p1.x) + 3 * tt * (p3.x - p2.x);
    const dy = 3 * uu * (p1.y - p0.y) + 6 * u * t * (p2.y - p1.y) + 3 * tt * (p3.y - p2.y);
    const angle = (Math.atan2(dy, dx) * 180) / Math.PI;

    return { x, y, angle };
  };

  const progressFraction = Math.min(1, Math.max(0, routeProgress / 100));
  const currentPos = getCoordinatesAlongPath(progressFraction);

  // Auto-drive simulation loop
  useEffect(() => {
    let interval;
    if (isSimulating && routeProgress < 100) {
      interval = setInterval(() => {
        const nextProgress = Math.min(100, routeProgress + 2 * speedMultiplier);
        const nextDist = Math.max(0, parseFloat((2.4 * (1 - nextProgress / 100)).toFixed(1)));
        const nextEta = Math.max(0, Math.ceil(8 * (1 - nextProgress / 100)));

        updateMechanicLocation(28.6180, 77.2120, nextDist, nextEta, nextProgress);

        if (nextProgress >= 100) {
          setIsSimulating(false);
          updateStep(7, 'ARRIVED');
        }
      }, 500);
    }
    return () => clearInterval(interval);
  }, [isSimulating, routeProgress, speedMultiplier]);

  return (
    <div className="relative w-full rounded-2xl overflow-hidden border border-slate-800 bg-[#0A101D] shadow-2xl">
      {/* Map Header Status Overlay */}
      <div className="absolute top-4 left-4 right-4 z-20 flex flex-wrap items-center justify-between gap-3 pointer-events-none">
        
        {/* Live Tracking Pill */}
        <div className="pointer-events-auto flex items-center space-x-3 bg-slate-900/95 backdrop-blur-md px-4 py-2.5 rounded-xl border border-slate-700 shadow-xl">
          <div className="relative flex items-center justify-center">
            <span className="w-3 h-3 rounded-full bg-emerald-400 animate-ping absolute"></span>
            <span className="w-3 h-3 rounded-full bg-emerald-500 relative"></span>
          </div>
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
              Live Mechanic GPS
            </div>
            <div className="text-sm font-extrabold text-white flex items-center space-x-2">
              <span className="text-emerald-400">{distanceKm} km away</span>
              <span className="text-slate-500">•</span>
              <span className="text-cyan-300">Arriving in {etaMinutes} min</span>
            </div>
          </div>
        </div>

        {/* Simulation Controls */}
        <div className="pointer-events-auto flex items-center space-x-2 bg-slate-900/95 backdrop-blur-md p-1.5 rounded-xl border border-slate-700 shadow-xl">
          <button
            onClick={() => setIsSimulating(!isSimulating)}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              isSimulating
                ? 'bg-amber-500 text-slate-950'
                : 'bg-emerald-500 text-slate-950 hover:bg-emerald-400'
            }`}
          >
            {isSimulating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
            <span>{isSimulating ? 'Pause Van' : 'Simulate Live Route'}</span>
          </button>

          <button
            onClick={() => setSpeedMultiplier(prev => (prev === 1 ? 2 : prev === 2 ? 4 : 1))}
            className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-300 border border-slate-700"
            title="Toggle simulation speed"
          >
            {speedMultiplier}x Speed
          </button>

          <button
            onClick={() => {
              updateMechanicLocation(28.6139, 77.2090, 0, 0, 100);
              updateStep(7, 'ARRIVED');
            }}
            className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-cyan-600/30 hover:bg-cyan-600/40 text-cyan-300 text-xs font-bold border border-cyan-500/40"
          >
            <CheckCircle className="w-3.5 h-3.5" />
            <span>Mark Arrived</span>
          </button>
        </div>
      </div>

      {/* Interactive Road Vector Map SVG */}
      <div className="relative w-full h-[360px] sm:h-[420px] bg-[#070D18]">
        <svg
          viewBox="0 0 760 400"
          className="w-full h-full select-none"
          preserveAspectRatio="xMidYMid slice"
        >
          <defs>
            {/* Dark Map Grid Pattern */}
            <pattern id="roadGrid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#101A2D" strokeWidth="1" />
            </pattern>

            {/* Glowing route line filter */}
            <filter id="routeGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>

            {/* Gradient for highway */}
            <linearGradient id="routeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#06B6D4" />
              <stop offset="100%" stopColor="#22C55E" />
            </linearGradient>
          </defs>

          {/* Map Grid Background */}
          <rect width="760" height="400" fill="#060C17" />
          <rect width="760" height="400" fill="url(#roadGrid)" />

          {/* City / Highway secondary roads */}
          <path d="M 0 160 Q 200 150 400 180 T 760 160" stroke="#13213B" strokeWidth="12" fill="none" />
          <path d="M 220 0 L 220 400" stroke="#13213B" strokeWidth="8" fill="none" />
          <path d="M 500 0 L 500 400" stroke="#13213B" strokeWidth="8" fill="none" />
          <path d="M 0 320 Q 300 310 760 340" stroke="#13213B" strokeWidth="10" fill="none" />

          {/* Primary Highway NH 44 (Underlying road surface) */}
          <path
            d="M 120 90 C 280 60, 420 310, 620 260"
            stroke="#1E293B"
            strokeWidth="20"
            strokeLinecap="round"
            fill="none"
          />
          {/* Highway dashed center lane */}
          <path
            d="M 120 90 C 280 60, 420 310, 620 260"
            stroke="#334155"
            strokeWidth="2"
            strokeDasharray="8 8"
            fill="none"
          />

          {/* Active Navigation Route (Cyan to Green Glow) */}
          <path
            d="M 120 90 C 280 60, 420 310, 620 260"
            stroke="url(#routeGradient)"
            strokeWidth="6"
            strokeLinecap="round"
            strokeDasharray="720"
            strokeDashoffset={720 * (1 - progressFraction)}
            filter="url(#routeGlow)"
            fill="none"
            className="transition-all duration-300"
          />

          {/* Landmark Road Signs */}
          <g transform="translate(180, 50)">
            <rect x="0" y="0" width="84" height="24" rx="4" fill="#0F172A" stroke="#334155" strokeWidth="1" />
            <text x="42" y="16" fill="#94A3B8" fontSize="10" fontWeight="bold" textAnchor="middle">
              EXIT 122 B
            </text>
          </g>

          <g transform="translate(460, 200)">
            <rect x="0" y="0" width="120" height="26" rx="4" fill="#047857" stroke="#10B981" strokeWidth="1.5" />
            <text x="60" y="17" fill="#FFFFFF" fontSize="11" fontWeight="bold" textAnchor="middle">
              NH 44 EXPRESSWAY
            </text>
          </g>

          {/* Origin / Mechanic Garage Point */}
          <g transform="translate(120, 90)">
            <circle r="16" fill="#0F172A" stroke="#06B6D4" strokeWidth="2" />
            <circle r="6" fill="#06B6D4" />
            <text x="0" y="32" fill="#38BDF8" fontSize="11" fontWeight="bold" textAnchor="middle">
              Mech Station
            </text>
          </g>

          {/* Destination: Vehicle Breakdown Location */}
          <g transform="translate(620, 260)">
            {/* Pulsing Radar rings */}
            <circle r="36" fill="rgba(239, 68, 68, 0.1)" stroke="rgba(239, 68, 68, 0.4)" strokeWidth="1.5">
              <animate attributeName="r" values="16;45;60" dur="2s" repeatCount="indefinite" />
              <animate attributeName="opacity" values="1;0.5;0" dur="2s" repeatCount="indefinite" />
            </circle>
            <circle r="18" fill="#7F1D1D" stroke="#EF4444" strokeWidth="2.5" />
            
            {/* Car Icon Pin */}
            <text x="0" y="5" fill="#FFFFFF" fontSize="14" textAnchor="middle">
              🚗
            </text>

            {/* Label Pin */}
            <g transform="translate(-85, -55)">
              <rect width="170" height="34" rx="8" fill="#18181B" stroke="#EF4444" strokeWidth="1.5" filter="drop-shadow(0 4px 6px rgba(0,0,0,0.5))" />
              <text x="85" y="15" fill="#EF4444" fontSize="10" fontWeight="900" textAnchor="middle">
                ⚠️ BREAKDOWN LOCATION
              </text>
              <text x="85" y="27" fill="#E4E4E7" fontSize="9" fontWeight="600" textAnchor="middle">
                {currentRequest?.location?.address || 'NH 44, Near Exit 123'}
              </text>
            </g>
          </g>

          {/* MOVING MECHANIC SERVICE VAN */}
          <g
            transform={`translate(${currentPos.x}, ${currentPos.y}) rotate(${currentPos.angle})`}
            className="transition-transform duration-300 ease-out"
          >
            {/* Van shadow */}
            <ellipse cx="0" cy="5" rx="22" ry="12" fill="rgba(0,0,0,0.6)" filter="blur(2px)" />

            {/* Van Body (Mech on Wheels Mobile Unit) */}
            <rect x="-22" y="-12" width="44" height="24" rx="5" fill="#065F46" stroke="#10B981" strokeWidth="2" />
            <rect x="6" y="-10" width="14" height="20" rx="3" fill="#1E293B" stroke="#34D399" strokeWidth="1" />
            
            {/* Headlights beams */}
            <polygon points="22,-8 48,-16 48,16 22,8" fill="rgba(250, 204, 21, 0.15)" />
            <circle cx="22" cy="-6" r="2" fill="#FEF08A" />
            <circle cx="22" cy="6" r="2" fill="#FEF08A" />

            {/* Top emergency flasher */}
            <circle cx="-5" cy="0" r="4" fill="#06B6D4">
              <animate attributeName="fill" values="#06B6D4;#22C55E;#06B6D4" dur="0.8s" repeatCount="indefinite" />
            </circle>

            {/* Tool / Wrench icon text */}
            <text x="-4" y="3" fill="#FFFFFF" fontSize="8" fontWeight="bold" textAnchor="middle">
              🔧
            </text>
          </g>
        </svg>

        {/* Map Footer Bar */}
        <div className="absolute bottom-3 left-4 right-4 z-20 flex items-center justify-between text-xs text-slate-400 bg-slate-900/90 backdrop-blur-md px-3.5 py-2 rounded-xl border border-slate-800">
          <div className="flex items-center space-x-2">
            <Compass className="w-4 h-4 text-emerald-400 animate-spin" style={{ animationDuration: '10s' }} />
            <span>Assigned: <strong className="text-white">{currentRequest?.selectedMechanic?.name || 'Mech Pro'}</strong></span>
            <span className="text-slate-600">|</span>
            <span className="text-slate-300">{currentRequest?.selectedMechanic?.vanModel || 'Mech Mobile Van DL 04 MP 1850'}</span>
          </div>
          <div className="font-semibold text-emerald-400">
            Speed: ~45 km/h
          </div>
        </div>
      </div>
    </div>
  );
};
