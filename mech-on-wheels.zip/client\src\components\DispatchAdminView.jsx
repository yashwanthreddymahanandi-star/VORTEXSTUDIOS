import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Activity,
  Users,
  Car,
  DollarSign,
  Clock,
  ShieldCheck,
  CheckCircle,
  AlertTriangle,
  Database,
  ExternalLink
} from 'lucide-react';

export const DispatchAdminView = () => {
  const {
    requestsList,
    mechanicsList,
    stats,
    currentRequest,
    setCurrentRequest,
    setIsMongoModalOpen,
    mongoStatus
  } = useApp();

  return (
    <div className="space-y-6">
      
      {/* Top Operations Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase text-slate-400">Active Breakdowns</span>
            <div className="w-8 h-8 rounded-lg bg-rose-500/10 text-rose-400 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white mt-2">
            {stats?.activeBreakdowns || 1}
          </div>
          <div className="text-[10px] text-emerald-400 font-semibold mt-1 flex items-center space-x-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
            <span>Real-time dispatching</span>
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase text-slate-400">Mobile Mechanics</span>
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white mt-2">
            {mechanicsList.length || 3}
          </div>
          <div className="text-[10px] text-cyan-400 font-semibold mt-1">
            100% On-Duty & Verified
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase text-slate-400">Avg Response Time</span>
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white mt-2">
            {stats?.avgResponseMinutes || 12} mins
          </div>
          <div className="text-[10px] text-slate-400 font-semibold mt-1">
            Fastest: 8 min (Mech Pro)
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase text-slate-400">Platform Revenue</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-emerald-400 mt-2">
            ₹{(stats?.totalRevenue || 1850).toLocaleString()}
          </div>
          <div className="text-[10px] text-slate-400 font-semibold mt-1">
            Minimal 5% commission
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Active Breakdown Callouts Table */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
            <div className="flex items-center space-x-2">
              <Car className="w-5 h-5 text-emerald-400" />
              <h3 className="text-base font-bold text-white">Breakdown Requests Log</h3>
            </div>
            <span className="text-xs text-slate-400 font-semibold">
              Total: {requestsList.length} Requests
            </span>
          </div>

          <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
            {requestsList.map((req) => {
              const isSelected = currentRequest?._id === req._id;
              return (
                <div
                  key={req._id}
                  onClick={() => setCurrentRequest(req)}
                  className={`p-4 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-950 border-emerald-500/60 ring-1 ring-emerald-500/30'
                      : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-extrabold text-white text-sm">
                          {req.customerName}
                        </span>
                        <span className="text-xs text-slate-400">
                          ({req.vehicle?.make} {req.vehicle?.model})
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                          {req.vehicle?.regNumber}
                        </span>
                      </div>
                      <div className="text-xs text-emerald-400 font-medium mt-1">
                        📍 {req.location?.address}
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        Issue: <span className="text-rose-400 font-semibold">{req.issue?.category}</span>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <span className={`inline-block text-[10px] font-black uppercase px-2.5 py-1 rounded-full ${
                        req.status === 'COMPLETED' || req.status === 'REVIEWED'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : req.status === 'EN_ROUTE'
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      }`}>
                        Step {req.currentStep}: {req.status}
                      </span>
                      <div className="text-xs font-bold text-white mt-2">
                        ₹{req.estimate?.totalAmount || 1850}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Verified Mechanics Fleet */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <ShieldCheck className="w-5 h-5 text-cyan-400" />
              <h3 className="text-base font-bold text-white">Verified Mechanics</h3>
            </div>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
              3 Online
            </span>
          </div>

          <div className="space-y-3">
            {mechanicsList.map((m) => (
              <div
                key={m._id}
                className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2 text-xs"
              >
                <div className="flex items-center space-x-3">
                  <img
                    src={m.avatar}
                    alt={m.name}
                    className="w-10 h-10 rounded-xl object-cover border border-slate-700"
                  />
                  <div>
                    <h4 className="font-bold text-white text-sm">{m.name}</h4>
                    <p className="text-slate-400 text-[11px]">{m.shopName || m.workshopName}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-slate-300 pt-1">
                  <span>Rating: ★{m.rating} ({m.reviewCount} reviews)</span>
                  <span className="text-cyan-400 font-semibold">{m.vehicle?.plateNumber}</span>
                </div>

                <div className="flex flex-wrap gap-1 pt-1">
                  {m.specialties?.slice(0, 3).map((s, i) => (
                    <span key={i} className="text-[10px] px-2 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* MongoDB Integration Card */}
          <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/30 text-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-emerald-300 flex items-center space-x-1">
                <Database className="w-3.5 h-3.5" />
                <span>MongoDB Storage</span>
              </span>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                mongoStatus.connected ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-300'
              }`}>
                {mongoStatus.connected ? 'Live MongoDB' : 'Ready to Connect'}
              </span>
            </div>
            <p className="text-slate-400 text-[11px]">
              Collection: <strong className="text-slate-200">servicerequests</strong> & <strong className="text-slate-200">users</strong>.
            </p>
            <button
              onClick={() => setIsMongoModalOpen(true)}
              className="w-full py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 font-bold text-xs border border-emerald-500/30"
            >
              Configure MongoDB URI
            </button>
          </div>

        </div>

      </div>

    </div>
  );
};
