import React from 'react';
import { useApp } from './context/AppContext';
import { LoginScreen } from './components/LoginScreen';
import { Navbar } from './components/Navbar';
import { TwelveStepBar } from './components/TwelveStepBar';
import { DriverView } from './components/DriverView';
import { MechanicView } from './components/MechanicView';
import { DispatchAdminView } from './components/DispatchAdminView';
import { HowItWorksModal } from './components/HowItWorksModal';
import { MongoModal } from './components/MongoModal';
import { InvoiceModal } from './components/InvoiceModal';
import { CheckCircle2, AlertCircle, Info } from 'lucide-react';

function AppContent() {
  const { user, role, notification } = useApp();

  // If user not authenticated, show Social Login first (Google, Apple, Microsoft)
  if (!user) {
    return <LoginScreen />;
  }

  return (
    <div className="min-h-screen bg-[#070C18] text-slate-100 flex flex-col">
      {/* Navigation Header */}
      <Navbar />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-4">
        
        {/* 12-Step Visual Roadmap from Image 2 */}
        <TwelveStepBar />

        {/* Dynamic View based on Role */}
        <div className="mt-4">
          {role === 'customer' && <DriverView />}
          {role === 'mechanic' && <MechanicView />}
          {role === 'dispatch' && <DispatchAdminView />}
        </div>
      </main>

      {/* Floating Toast Notification */}
      {notification && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center space-x-2.5 px-4 py-3 rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl text-xs font-semibold animate-slide-up text-white">
          {notification.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : notification.type === 'error' ? (
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          ) : (
            <Info className="w-4 h-4 text-cyan-400 shrink-0" />
          )}
          <span>{notification.message}</span>
        </div>
      )}

      {/* Modals */}
      <HowItWorksModal />
      <MongoModal />
      <InvoiceModal />

      {/* Footer */}
      <footer className="mt-12 py-6 border-t border-slate-800/80 bg-slate-950/60 text-center text-xs text-slate-500">
        <p>
          Mech On Wheels • MERN Stack Platform with MongoDB, Express, React & Node.js • Real-Time Socket.io GPS Assistance
        </p>
      </footer>
    </div>
  );
}

export default function App() {
  return <AppContent />;
}
