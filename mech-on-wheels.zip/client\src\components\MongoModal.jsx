import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Database, CheckCircle, AlertTriangle, RefreshCw, Server, ArrowRight } from 'lucide-react';

export const MongoModal = () => {
  const { isMongoModalOpen, setIsMongoModalOpen, mongoStatus, connectMongoDB } = useApp();
  const [uri, setUri] = useState(mongoStatus.uri || 'mongodb://127.0.0.1:27017/mech_on_wheels');
  const [isLoading, setIsLoading] = useState(false);
  const [feedback, setFeedback] = useState(null);

  if (!isMongoModalOpen) return null;

  const handleConnect = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setFeedback(null);
    try {
      const res = await connectMongoDB(uri);
      setFeedback({ type: 'success', text: 'Connected to MongoDB successfully!' });
    } catch (err) {
      setFeedback({
        type: 'error',
        text: err.response?.data?.error || err.message || 'Could not connect. Verify MongoDB is running or check Atlas URI.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-[#0B1120] border border-slate-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl relative">
        
        {/* Close Button */}
        <button
          onClick={() => setIsMongoModalOpen(false)}
          className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center space-x-3 mb-5">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center">
            <Database className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white flex items-center space-x-2">
              <span>MongoDB Connection</span>
              <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
                mongoStatus.connected
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
              }`}>
                {mongoStatus.connected ? 'Active & Connected' : 'Disconnected'}
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              MERN Stack database configuration & live data persistence
            </p>
          </div>
        </div>

        {/* Status Card */}
        <div className="bg-slate-950 rounded-2xl p-4 border border-slate-800 space-y-2 text-xs mb-5">
          <div className="flex justify-between items-center">
            <span className="text-slate-400">Database Name:</span>
            <span className="font-mono font-bold text-emerald-400">{mongoStatus.databaseName || 'mech_on_wheels'}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-slate-400">Mongoose Collections:</span>
            <span className="font-mono text-slate-200">users, servicerequests, quotes</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-slate-400">Current Target URI:</span>
            <span className="font-mono text-slate-300 truncate max-w-[240px]">{mongoStatus.uri}</span>
          </div>
        </div>

        {/* URI Form */}
        <form onSubmit={handleConnect} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              MongoDB Connection URI (Local or Atlas)
            </label>
            <input
              type="text"
              value={uri}
              onChange={(e) => setUri(e.target.value)}
              required
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
              placeholder="mongodb://127.0.0.1:27017/mech_on_wheels"
            />
            <p className="text-[11px] text-slate-400 mt-1">
              Examples:
              <br />
              • Local: <code className="text-emerald-400">mongodb://127.0.0.1:27017/mech_on_wheels</code>
              <br />
              • Atlas: <code className="text-cyan-400">mongodb+srv://username:password@cluster.mongodb.net/mech_on_wheels</code>
            </p>
          </div>

          {feedback && (
            <div className={`p-3 rounded-xl text-xs flex items-center space-x-2 ${
              feedback.type === 'success'
                ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                : 'bg-rose-500/10 text-rose-300 border border-rose-500/30'
            }`}>
              {feedback.type === 'success' ? <CheckCircle className="w-4 h-4 shrink-0" /> : <AlertTriangle className="w-4 h-4 shrink-0" />}
              <span>{feedback.text}</span>
            </div>
          )}

          <div className="flex items-center justify-end space-x-3 pt-2">
            <button
              type="button"
              onClick={() => setIsMongoModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
            >
              Close
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 flex items-center space-x-1.5"
            >
              {isLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Database className="w-3.5 h-3.5" />}
              <span>{isLoading ? 'Connecting to MongoDB...' : 'Connect to MongoDB'}</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
