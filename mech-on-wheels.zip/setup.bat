@echo off
echo ========================================================
echo   Setting up Mech On Wheels (MERN Roadside Platform)
echo ========================================================
echo.

echo [1/3] Installing Backend Dependencies...
cd server
call npm install
if %errorlevel% neq 0 (
    echo Error installing backend dependencies.
    pause
    exit /b %errorlevel%
)
cd ..

echo [2/3] Installing Frontend Dependencies...
cd client
call npm install
if %errorlevel% neq 0 (
    echo Error installing frontend dependencies.
    pause
    exit /b %errorlevel%
)

echo [3/3] Building Frontend Assets...
call npm run build
cd ..

echo.
echo ========================================================
echo   Setup Completed Successfully!
echo   Starting Mech On Wheels Full-Stack Application...
echo   Open in browser: http://localhost:5000
echo ========================================================
echo.
cd server
npm start
