import React from 'react';
import { useApp } from '../context/AppContext';
import { X, CheckCircle2, ShieldCheck, Clock, DollarSign, Wrench, Car, Phone, Navigation } from 'lucide-react';

export const HowItWorksModal = () => {
  const { isHowItWorksOpen, setIsHowItWorksOpen } = useApp();

  if (!isHowItWorksOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-[#0B1120] border border-slate-800 rounded-3xl max-w-4xl w-full p-6 sm:p-8 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        
        {/* Close Button */}
        <button
          onClick={() => setIsHowItWorksOpen(false)}
          className="absolute top-6 right-6 p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center max-w-xl mx-auto mb-8">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold mb-3">
            <Wrench className="w-3.5 h-3.5" />
            <span>HOW MECH ON WORKS</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            Dual Platform: Vehicle Owners & Local Mechanics
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-2">
            Connecting stranded drivers on highways with certified mobile mechanics in real-time.
          </p>
        </div>

        {/* 2-Column Comparison from Image 1 */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          
          {/* Column 1: For Vehicle Owners */}
          <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-6 space-y-5">
            <div className="flex items-center space-x-3 pb-3 border-b border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center">
                <Car className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-white">For Vehicle Owners</h3>
            </div>

            <div className="space-y-4">
              <div className="flex items-start space-x-3.5">
                <div className="w-6 h-6 rounded-full bg-orange-500 text-slate-950 flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                  1
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Raise a Request</h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Open the app, share your exact breakdown location, and define your vehicle issue.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3.5">
                <div className="w-6 h-6 rounded-full bg-orange-500 text-slate-950 flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                  2
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Compare Competitive Quotes</h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Nearby verified mechanics review your callout and send transparent price quotes.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3.5">
                <div className="w-6 h-6 rounded-full bg-orange-500 text-slate-950 flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                  3
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Repair & Continue</h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Select your mechanic based on price, ratings, and experience to get fixed on the spot.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Column 2: For Local Mechanics */}
          <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-6 space-y-5">
            <div className="flex items-center space-x-3 pb-3 border-b border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                <Wrench className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-white">For Local Mechanics</h3>
            </div>

            <div className="space-y-4">
              <div className="flex items-start space-x-3.5">
                <div className="w-6 h-6 rounded-full bg-cyan-500 text-slate-950 flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                  1
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Receive Alerts</h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Get instant notifications straight to your phone when drivers break down nearby.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3.5">
                <div className="w-6 h-6 rounded-full bg-cyan-500 text-slate-950 flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                  2
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Send Quotation</h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Submit your fair price estimate and estimated arrival window instantly.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3.5">
                <div className="w-6 h-6 rounded-full bg-cyan-500 text-slate-950 flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                  3
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Grow Your Income</h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Complete repairs and expand your business retention with minimal commission fees.
                  </p>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* 12-Step Journey Summary */}
        <div className="bg-slate-950 rounded-2xl p-6 border border-slate-800">
          <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400 mb-4 flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>Complete 12-Step On-Demand Architecture (Image 2)</span>
          </h4>

          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 text-xs">
            {[
              '1. Vehicle Breakdown',
              '2. Open App & Request',
              '3. Seen by Mechanics',
              '4. Choose Best Option',
              '5. Assignment Confirmed',
              '6. Track in Real-Time',
              '7. On-Site Diagnosis',
              '8. Transparent Pricing',
              '9. Repair in Progress',
              '10. Pay Securely In-App',
              '11. Back on the Road',
              '12. Rate & Review'
            ].map((st, i) => (
              <div key={i} className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 font-medium">
                {st}
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button
            onClick={() => setIsHowItWorksOpen(false)}
            className="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs"
          >
            Got It! Close Guide
          </button>
        </div>

      </div>
    </div>
  );
};
