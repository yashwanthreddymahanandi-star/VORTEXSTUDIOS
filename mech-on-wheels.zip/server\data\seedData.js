export const defaultMechanics = [
  {
    _id: 'mech_001',
    name: 'Rajesh Kumar (Mech Pro)',
    shopName: 'Mech Pro Express',
    phone: '+91 98765 43210',
    email: 'rajesh.mechpro@gmail.com',
    role: 'mechanic',
    avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=160&auto=format&fit=crop&q=80',
    rating: 4.8,
    reviewCount: 148,
    experienceYears: 9,
    isVerified: true,
    isOnline: true,
    workshopName: 'Mech Pro Roadside HQ, NH 44',
    specialties: ['Engine Diagnostics', 'Electrical Systems', 'Battery Jumpstart', 'Fuel Systems'],
    location: {
      address: 'NH 44, Milepost 41, Service Hub A',
      lat: 28.6250,
      lng: 77.2180
    },
    vehicle: {
      type: 'Service Van',
      model: 'Mech On Wheels Rapid Response Van',
      plateNumber: 'DL 04 MP 1850'
    },
    earnings: {
      total: 34500,
      completedJobs: 28,
      commissionRate: 0.05
    }
  },
  {
    _id: 'mech_002',
    name: 'Amit Sharma (FixIt Auto)',
    shopName: 'FixIt Auto Care',
    phone: '+91 98111 22334',
    email: 'amit.fixit@gmail.com',
    role: 'mechanic',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&auto=format&fit=crop&q=80',
    rating: 4.6,
    reviewCount: 96,
    experienceYears: 7,
    isVerified: true,
    isOnline: true,
    workshopName: 'FixIt Auto Garage & Towing',
    specialties: ['Flat Tyre On-Site', 'Brake Failure', 'Coolant Overheating', 'Alternator'],
    location: {
      address: 'Ring Road Bypass, Near Sector 14',
      lat: 28.6310,
      lng: 77.2240
    },
    vehicle: {
      type: 'Service Van',
      model: 'FixIt Mobile Workshop Cruiser',
      plateNumber: 'HR 26 FA 2150'
    },
    earnings: {
      total: 27800,
      completedJobs: 21,
      commissionRate: 0.05
    }
  },
  {
    _id: 'mech_003',
    name: 'Vikram Singh (Speedy Service)',
    shopName: 'Speedy Service 24/7',
    phone: '+91 98222 33445',
    email: 'vikram.speedy@gmail.com',
    role: 'mechanic',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=160&auto=format&fit=crop&q=80',
    rating: 4.7,
    reviewCount: 112,
    experienceYears: 11,
    isVerified: true,
    isOnline: true,
    workshopName: 'Speedy Master Garage',
    specialties: ['Towing & Recovery', 'Heavy Engine Trouble', 'Transmission', 'Suspension'],
    location: {
      address: 'Expressway Toll Junction, Point 3',
      lat: 28.6080,
      lng: 77.1990
    },
    vehicle: {
      type: 'Towing & Mobile Unit',
      model: 'Speedy Heavy Duty Assistance Truck',
      plateNumber: 'UP 16 SS 2400'
    },
    earnings: {
      total: 41200,
      completedJobs: 33,
      commissionRate: 0.05
    }
  }
];

export const sampleRequests = [
  {
    _id: 'req_sample_101',
    customerName: 'Rohit Verma',
    customerPhone: '+91 98700 12345',
    vehicle: {
      make: 'Hyundai',
      model: 'Verna 1.6 SX',
      year: '2022',
      regNumber: 'DL 08 CD 4455',
      type: 'Car'
    },
    location: {
      address: 'NH 44, Near Exit 123, Flyover End',
      landmark: 'Near Milestone 123 & Petrol Pump',
      lat: 28.6139,
      lng: 77.2090
    },
    issue: {
      category: 'Engine Breakdown',
      description: 'Car stalled with battery and check engine warning light flashing. Sudden power loss while accelerating.',
      severity: 'Urgent (High)',
      symptoms: ['Engine Stall', 'Warning Lights', 'Smoke from Bonnet']
    },
    status: 'EN_ROUTE',
    currentStep: 6,
    selectedMechanic: {
      mechanicId: 'mech_001',
      name: 'Rajesh Kumar (Mech Pro)',
      shopName: 'Mech Pro Express',
      phone: '+91 98765 43210',
      rating: 4.8,
      avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=160&auto=format&fit=crop&q=80',
      vanModel: 'Mech On Wheels Rapid Response Van'
    },
    tracking: {
      mechanicLat: 28.6210,
      mechanicLng: 77.2140,
      driverLat: 28.6139,
      driverLng: 77.2090,
      distanceKm: 2.4,
      etaMinutes: 8,
      routeProgress: 35,
      speedKmh: 42
    },
    estimate: {
      serviceCharge: 1100,
      parts: 500,
      taxes: 250,
      totalAmount: 1850,
      notes: 'Roadside inspection, alternator connector replacement & quick system reboot',
      approvedByCustomer: true,
      approvedAt: new Date()
    },
    payment: {
      amount: 1850,
      status: 'Pending',
      method: 'UPI',
      invoiceNumber: 'INV-MOW-2026-8812',
      transactionId: '',
      paidAt: null
    },
    review: {
      rating: 0,
      feedback: '',
      tags: [],
      createdAt: null
    },
    createdAt: new Date(Date.now() - 1000 * 60 * 15)
  }
];
