import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const rootDir = __dirname;
const stagingDir = path.join(rootDir, 'mech-on-wheels-staging');
const zipFile = path.join(rootDir, 'mech-on-wheels.zip');

console.log('📦 Packaging Mech On Wheels project into clean ZIP...');

// Remove old staging & zip if present
if (fs.existsSync(stagingDir)) {
  fs.rmSync(stagingDir, { recursive: true, force: true });
}
if (fs.existsSync(zipFile)) {
  fs.rmSync(zipFile, { force: true });
}

fs.mkdirSync(stagingDir, { recursive: true });

const IGNORE_PATTERNS = [
  'node_modules',
  '.git',
  'mech-on-wheels-staging',
  'mech-on-wheels.zip',
  '.system_generated',
  '.user_uploaded'
];

function shouldIgnore(name) {
  return IGNORE_PATTERNS.some(pattern => name === pattern || name.startsWith(pattern));
}

function copyFolderRecursiveSync(source, target) {
  if (!fs.existsSync(target)) {
    fs.mkdirSync(target, { recursive: true });
  }

  const files = fs.readdirSync(source);
  for (const file of files) {
    if (shouldIgnore(file)) continue;

    const curSource = path.join(source, file);
    const curTarget = path.join(target, file);

    const stat = fs.statSync(curSource);
    if (stat.isDirectory()) {
      copyFolderRecursiveSync(curSource, curTarget);
    } else {
      fs.copyFileSync(curSource, curTarget);
    }
  }
}

// Copy source files
copyFolderRecursiveSync(rootDir, stagingDir);
console.log('✅ Staged files successfully (excluded node_modules and temporary folders)');

// Run PowerShell Compress-Archive
try {
  const psCmd = `powershell -Command "Compress-Archive -Path '${stagingDir}\\*' -DestinationPath '${zipFile}' -Force"`;
  execSync(psCmd, { stdio: 'inherit' });
  console.log(`🎉 Successfully created ZIP file at:\n👉 ${zipFile}`);
  const stats = fs.statSync(zipFile);
  console.log(`📊 Size: ${(stats.size / 1024).toFixed(2)} KB`);
} catch (err) {
  console.error('Error creating archive:', err.message);
} finally {
  // Cleanup staging dir
  if (fs.existsSync(stagingDir)) {
    fs.rmSync(stagingDir, { recursive: true, force: true });
  }
}
